-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2017 at 08:30 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashion`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user_name`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `p_id` int(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `price` int(225) NOT NULL,
  `total` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `id_no` int(20) NOT NULL,
  `email` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `body` varchar(225) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_name`, `email`, `subject`, `body`, `time`) VALUES
(1, 'Gee', 'kamaugerald2@gmail.com', 'Awesome', 'nnn', '2017-06-29 19:50:45'),
(2, 'Gee', 'kamaugerald2@gmail.com', 'Awesome', 'FGDGFDDGFDDFF', '2017-06-29 20:42:06'),
(3, 'Gee', 'kamaugerald2@gmail.com', 'GOOD SERVICE', 'the delivery was quick', '2017-06-29 20:43:24'),
(4, 'dan@gmail.com', 'dan@gmail.com', 'clothes', 'poor service', '2017-06-30 12:18:15'),
(5, 'dan@gmail.com', 'dan@gmail.com', 'clothes', 'services were good', '2017-06-30 12:35:39');

-- --------------------------------------------------------

--
-- Table structure for table `kids`
--

CREATE TABLE `kids` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `size` varchar(30) NOT NULL,
  `price` varchar(20) NOT NULL,
  `image` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kids`
--

INSERT INTO `kids` (`id`, `name`, `size`, `price`, `image`) VALUES
(1, 'dresses', 'S', '499', 'p23.jpg'),
(2, 'boys wear ', 'S', '2300', 'p25.jpg'),
(4, 'sweat pants', 'S', '800', 'one.jpg'),
(5, 'girls wear', 'S', '780', 'two.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `men`
--

CREATE TABLE `men` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `size` varchar(225) NOT NULL,
  `price` int(20) NOT NULL,
  `image` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `men`
--

INSERT INTO `men` (`id`, `name`, `size`, `price`, `image`) VALUES
(1, 'tshirt\r\n', 'S/M/L/XL', 999, 'p9.jpg'),
(2, 'hoods', 'S/M/L', 699, 'p27.jpg'),
(3, 'Sneaker', '38/39/40/41', 1999, 's3.jpg'),
(4, 'offical wear', 'M/L/XL', 1999, 'woo3.jpg'),
(5, 'watch', 'S/M/L', 4999, 'P29.jpg'),
(6, 'caps', 'M/L', 499, 's8.jpg'),
(7, 'tshirt', '40', 3500, 'p9.jpg'),
(8, 'tshirt', 'xx', 3500, 'p12.jpg'),
(9, 'jordans', '40', 3500, 'l2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `products` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(20) NOT NULL,
  `date` date NOT NULL,
  `client_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `products`, `quantity`, `price`, `date`, `client_name`) VALUES
(0, 'sneakers', 2, 3400, '2017-06-04', 'Dennis'),
(0, 'Tshirts', 1, 800, '2017-06-07', 'John Mweu');

-- --------------------------------------------------------

--
-- Table structure for table `orderss`
--

CREATE TABLE `orderss` (
  `id` int(11) NOT NULL,
  `item` varchar(225) NOT NULL,
  `quantity` int(20) NOT NULL,
  `price` int(20) NOT NULL,
  `user` varchar(225) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderss`
--

INSERT INTO `orderss` (`id`, `item`, `quantity`, `price`, `user`, `date`) VALUES
(1, 'sneakers', 4, 3400, 'Dennis Nyamai', '2017-06-08 11:34:41'),
(2, 'Shirts', 4, 800, 'Daniel Mbogo', '2017-06-07 08:25:37'),
(3, 'Dresses', 4, 750, 'Irene Wambui', '2017-06-07 10:31:42'),
(4, 'Caps', 1, 1500, 'Gerald K', '2017-06-07 11:00:34'),
(5, 'Sweat pants', 2, 600, 'Anthony', '2017-06-08 07:27:47'),
(6, 'Jumpers', 2, 600, 'Eva ', '2017-06-08 11:34:41'),
(7, 'Socks', 3, 100, 'Erick', '2017-06-15 09:35:46'),
(8, 'shirts', 2, 900, 'Crispus', '2017-06-07 11:32:50'),
(9, 'Jordans', 1, 5000, 'Samuel', '2017-06-06 13:00:00'),
(10, 'bras', 5, 100, 'Anne', '2017-06-06 09:26:44'),
(11, 'handbags', 3, 3400, 'Lydia', '2017-06-30 11:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `wear_id` int(11) NOT NULL,
  `quantity` int(20) NOT NULL,
  `price` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `transaction` varchar(225) NOT NULL,
  `id_no` int(20) NOT NULL,
  `estate` varchar(225) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `transaction`, `id_no`, `estate`, `time`) VALUES
(1, 'K2472647272CV4', 31422876, '', '2017-06-02 11:33:00'),
(2, 'K2472647272CV4', 31422876, '', '2017-06-02 11:37:21'),
(3, 'K2472647272CV4', 31422876, '', '2017-06-09 05:34:03'),
(4, 'K2472647272CV4', 31422876, '', '2017-06-09 05:36:02'),
(5, 'K2472647272CV4', 31422876, '', '2017-06-09 10:24:32'),
(6, 'K2472647272CV4', 31422876, '', '2017-06-09 10:33:47'),
(7, 'K2472647272CV4', 31422876, '', '2017-06-09 10:46:56'),
(8, 'K2472647272CV4', 31422876, '', '2017-06-16 05:10:21'),
(9, 'K2472647272CV4', 31422876, '', '2017-06-16 05:36:17'),
(10, 'K2472647272CV4', 31422876, '', '2017-06-16 08:30:13'),
(11, 'K2472647272CV4', 31422876, '', '2017-06-16 08:30:36'),
(12, 'K2472647272CV4', 31422876, '', '2017-06-16 13:30:17'),
(13, 'K2472647272CV4', 31422876, '', '2017-06-16 14:01:09'),
(14, 'K2472647272CV4', 31422876, '', '2017-06-16 14:02:48'),
(15, 'K2472647272CV4', 31422876, 'California', '2017-06-28 17:21:44'),
(16, 'kfetfwewgdfg', 29789649, 'Bondeni', '2017-06-28 19:32:09'),
(17, 'kfetfwewgdfg', 4323532, 'Bondeni', '2017-06-28 19:37:55'),
(18, 'K2472647272CV4', 31422876, 'Kalundu', '2017-06-29 20:55:34'),
(19, 'K2472647272CV4', 31422876, 'Bondeni', '2017-06-30 07:00:25');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `id_no` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `phone` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `confirm_password` varchar(225) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `id_no`, `email`, `phone`, `password`, `confirm_password`, `date`) VALUES
(1, 'Gerald Kamau', '31422687', 'kamaugerald2@gmail.com', '+254713186336', '123456', '123456', '2017-05-24 18:08:50'),
(2, 'Gerald Kamau', '31422687', 'kamaugerald2@gmail.com', '+254713186336', '123456', '123456', '2017-05-24 18:10:18'),
(3, 'Gerald Kamau', '31422687', 'kamaugerald2@gmail.com', '+254713186336', '123', '123', '2017-05-24 20:38:35'),
(4, 'Gerald Kamau', '32289232', 'kamaugerald2@gmail.com', '+254713186336', '123', '123', '2017-05-24 20:43:37'),
(5, 'Mwangi', '32098102', 'a@gmail.com', '0708393155', '12345', '12345', '2017-05-29 13:30:53'),
(6, 'Dennis', '31422687', 'kamaugerald2@gmail.com', 'dan@gmail.com', '123456', '123456', '2017-06-16 04:35:05'),
(7, 'Gerald Kamau', '31422687', 'kamaugerald2@gmail.com', '+254713186336', '123456', '123455', '2017-06-16 08:37:58'),
(8, 'Dennis', '31422687', 'dan@gmail.com', '0714785554', '1234', '1234', '2017-06-16 13:27:16');

-- --------------------------------------------------------

--
-- Table structure for table `women`
--

CREATE TABLE `women` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `size` varchar(30) NOT NULL,
  `price` int(20) NOT NULL,
  `image` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `women`
--

INSERT INTO `women` (`id`, `name`, `size`, `price`, `image`) VALUES
(1, 'watch', 'M', 1200, 'i1.jpg'),
(2, 'handbag', 'M', 3400, 'i3.jpg'),
(3, 'heels', 'M,L', 2300, 'i6.jpg'),
(4, 'skirts', '40', 3500, 'i9.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kids`
--
ALTER TABLE `kids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `men`
--
ALTER TABLE `men`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderss`
--
ALTER TABLE `orderss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `women`
--
ALTER TABLE `women`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `kids`
--
ALTER TABLE `kids`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `men`
--
ALTER TABLE `men`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `orderss`
--
ALTER TABLE `orderss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `women`
--
ALTER TABLE `women`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
