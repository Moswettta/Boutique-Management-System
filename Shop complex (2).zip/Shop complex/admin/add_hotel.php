<!DOCTYPE HTML>
<HTML lang="en">
<head>
  <title>Stedmark</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery-1.12.3.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link href="bootstrap.css" rel='stylesheet' type='text/css' />
  <link rel="stylesheet" href='css/styles.css' type='text/css' media="all"/>
    <script>tinymce.init({ selector:'textarea' });</script>
<script type="text/javascript">
    function sureToApprove(id){
      if(confirm("Are you sure you want to delete this product?")){
        window.location.href ='delete_prod.php?id='+id;
      }
    }
  </script>
    </head>
    <body>
    <!-- main container starts her -->
  <div class="main_wrapper">
  <!-- header starts her -->
<header>
    <div class="jumbotron">
        <div class="col-md-9">
            <h3>
            <div class="glyphicon glyphicon-dashboard"></div>
                Rabuor Complex

            </h3>

        </div>
        <div class="col-md-3 col-sm-3">
        <h5>Welcome Administrator| <a href="admin_login.php"><div class="glyphicon glyphicon-log-out">logout</div></a>

        </h5>
        </div>
    </div>
</header>
  </div>
        



</div>

	<div class="container">
	<form action="add_kids.php" method="post" enctype="multipart/form-data">   
<div class="col-md-6">	
  <table class="table table-bordered">
    <thead>
	<h3>ADD A WEAR HERE</h3>
    </thead>
    <tbody>
	        
	  	        <tr>
        <td>Wear</td>
		<td><input type="text" class="form-control" name="name"></td>
      </tr>
	        <tr>
        <td>Wear_Price</td>
       	<td><input type="text" class="form-control" name="price"></td>
      </tr>
	        <tr>
        <td>Wear_Size</td>
        	<td><input type="text" class="form-control" name="size"></td>
      </tr>
	        <tr>
        <td>Wear_Image</td>
   	<td>
	<input type="file" class="form-control" name="image">
	</td>
      </tr>
	  <tr>
	  <td></td>
        <td><button type="submit" class="btn btn-primary" name="insert">INSERT KIDS CLOTHES</button></td>
      </tr>
      
    </tbody>
  </table>
	</form></form>
</div>
	</div>
	</body>
	<div class="col-md-2">

    <a href="home.php"><button type="button" class="btn btn-default">View Wears</button></a>
    </div>
</html>
<?php
include 'config/config.php';
//getting data from the form
if(isset($_POST['insert'])){
$name=$_POST['name'];
$size=$_POST['size'];
$price=$_POST['price'];

//getting image from the field
$product_image=$_FILES['image']['name'];
$product_image_tmp=$_FILES['image']['tmp_name'];
move_uploaded_file($product_image_tmp,"images/$product_image");
if(!empty($name) && !empty($size) && !empty($price) && !empty($product_image)){
$sql="INSERT INTO kids VALUES('','$name','$size','$price','$product_image')";

if($conn->query($sql)==TRUE){
echo "<script>
	alert('Successfully Inserted');
	window.location ('index.php');
	</script>";
}
}
}
?>
