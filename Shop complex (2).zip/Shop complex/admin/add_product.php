<?php
    error_reporting(0); // Suppresses all error reporting
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Stedmark</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script src="js/jquery-1.12.3.min.js"></script>
    <script type="text/javascript">
        function sureToApprove(id) {
            if (confirm("Are you sure you want to delete this product?")) {
                window.location.href = 'delete_prod.php?id=' + id;
            }
        }
    </script>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* Header styles */
        header {
            background-color: #007bff;
            color: white;
            padding: 15px 0;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }

        /* Sidebar styles */
        .sidebar {
            background-color: #333;
            color: white;
            padding-top: 20px;
            width: 220px; /* Increased for better visibility */
            height: calc(100vh - 65px); /* Adjust height considering header height */
            float: left; /* Makes the sidebar float left */
            z-index: 1;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 12px 15px; /* Adjusted padding for a more comfortable click area */
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        /* Content area */
        .content {
            margin-left: 240px; /* Adjusted this to account for sidebar width */
            padding: 20px;
            max-width: 800px; /* Set a max width for better content layout */
            margin: 0 auto; /* Center content */
        }

        /* Form styling */
        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px; /* Space between form and other elements */
        }

        h3 {
            margin-bottom: 15px; /* Space below the form title */
            font-size: 22px;
            color: #333;
        }

        label {
            margin-bottom: 8px;
            font-weight: bold;
            color: #555; /* Slightly darker label color */
        }

        input[type="text"],
        input[type="number"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s; /* Transition effect for input */
        }

        input[type="text"]:focus,
        input[type="number"]:focus {
            border-color: #007bff; /* Change border color on focus */
            outline: none; /* Remove outline */
        }

        img {
            width: 80px; /* Set desired width */
            height: 60px; /* Set desired height */
            object-fit: cover; /* Maintain aspect ratio */
            margin-bottom: 10px; /* Space between image and input */
        }

        /* Button styles */
        .btn {
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            color: white;
            background-color: #007bff;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.2s; /* Added transition effects */
        }

        .btn:hover {
            background-color: #0056b3; /* Darker on hover */
            transform: scale(1.05); /* Slightly enlarge on hover */
        }

        .btn-default {
            background-color: #6c757d; /* Secondary button color */
        }

        .btn-default:hover {
            background-color: #5a6268; /* Darker on hover for default button */
        }
    </style>
</head>
<body>
    <header>
         <?php include 'header.php'; ?>
    </header>

    <div class="main_wrapper">
        <!-- Sidebar Inclusion -->
        <div class="sidebar">
            <?php include 'sidebar.php'; ?>
        </div>

        <div class="content"> <!-- Changed from container to content for better semantics -->
            <form action="add_product.php" method="post" enctype="multipart/form-data">   
                <h3>ADD A WEAR HERE</h3>
                <table class="table">
                    <tbody>
                        <tr>
                            <td><label for="name">Wear</label></td>
                            <td><input type="text" class="form-control" name="name" required></td>
                        </tr>
                        <tr>
                            <td><label for="price">Price</label></td>
                            <td><input type="text" class="form-control" name="price" required></td>
                        </tr>
                        <tr>
                            <td><label for="size">Size</label></td>
                            <td><input type="text" class="form-control" name="size" required></td>
                        </tr>
                        <tr>
                            <td><label for="sum">Quantity</label></td>
                            <td><input type="number" class="form-control" name="sum" required min="1"></td>
                        </tr>
                        <tr>
                            <td><label for="image">Wear Image</label></td>
                            <td>
                                <input type="file" class="form-control" name="image" required>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <button type="submit" class="btn" name="insert">INSERT  CLOTHES</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>

            <div>
                <a href="home.php"><button type="button" class="btn btn-default">View Wears</button></a>
            </div>
        </div>
    </div>

    <?php
    include 'config/config.php';

    // Getting data from the form
    if (isset($_POST['insert'])) {
        $name = $_POST['name'];
        $size = $_POST['size'];
        $price = $_POST['price'];
        $sum = $_POST['sum'];

        // Getting image from the field
        $product_image = $_FILES['image']['name'];
        $product_image_tmp = $_FILES['image']['tmp_name'];
        $upload_dir = "images/";

        // Move the uploaded image file to the images directory
        if (move_uploaded_file($product_image_tmp, $upload_dir . $product_image)) {
            // Check if all fields are filled
            if (!empty($name) && !empty($size) && !empty($price) && !empty($sum) && !empty($product_image)) {
                // Insert data into the product table
                $sql = "INSERT INTO product (name, size, price, sum, image) VALUES ('$name', '$size', '$price', '$sum', '$product_image')";

                if ($conn->query($sql) === TRUE) {
                    echo "<script>
                        alert('Successfully Inserted');
                        window.location = 'product.php';
                        </script>";
                } else {
                    // Print SQL error message
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                echo "<script>alert('All fields are required!');</script>";
            }
        } else {
            echo "<script>alert('Image upload failed. Please try again.');</script>";
        }
    }
    ?>
</body>
</html>
