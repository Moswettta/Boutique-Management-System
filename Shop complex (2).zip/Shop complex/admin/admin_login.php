
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stedmark</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
 <link href="css/index.css" rel="stylesheet" type="text/css"/>
  <link href="css/school.css" rel="stylesheet" type="text/css"/>
 <link href="css/style2.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style1.css" rel="stylesheet" type="text/css" media="all" /> 
<style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;
  color: #777;
}

.bgimg-1, .bgimg-2, .bgimg-3 {
  position: relative;
  opacity: 0.65;
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

}
.bgimg-1 {
  background-image: url("images/one.jpg");
  min-height: 100%;
}

.bgimg-2 {
  background-image: url("images/two.jpg");
  min-height: 400px;
}

.bgimg-3 {
  background-image: url("images/three.jpg");
  min-height: 400px;
}

.caption {
  position: absolute;
  left: 0;
  top: 50%;
  width: 100%;
  text-align: center;
  color: #000;
}

.caption span.border {
  background-color: #111;
  color: #fff;
  padding: 18px;
  font-size: 25px;
  letter-spacing: 10px;
}

h3 {
  letter-spacing: 5px;
  text-transform: uppercase;
  font: 20px "Lato", sans-serif;
  color: #111;
}
.button {
  border-radius: 2px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 20px;
  width: 120px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: 20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
 <header id="header">
<div class="header">
<div class="container">
  <div class="logo-nav">
    <div class="logo-nav-left">
      <h3><a href="index.php">Rabuor Complex  <span>Rabuor</span></a></h3><br>
            </div>
            <div class="log-nav-main">
            <ul class="nav navbar-nav">
    <ul class="nav navbar-right">
        <nav class="navbar navbar-inverse">
      <div class="navbar-header"></div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">

        <ul class="nav navbar-nav" id="menu">
        <a href ="index.php"><button class="button "><span>Home</span></button></a>
        <a href ="admin_login.php"><button class="button "><span>Admin</span></button></a>

        <li><a href="logout.php"><span class=""></span></a></li>

        </ul>
        <ul class="nav navbar-right">
        </ul></div>
</a>
        </ul>
            </div>
</div>
</div>
</div>
  
</header>

<div class="container">
<header id="header">
</header>
	<section class="search">
		<div class="wrapper">
		<div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
</h3>
                </div>
                <div class="modal-body">
		<div id="fom">
			<form method="post">
		
				<table height="100" align="center">
					<tr>
						<div class="form-group">
                                        <label for="user_name">Username:</label>
                                        <input type="text" class="form-control" name="user_name" required>
                                    </div>
					</tr>
					<tr>
						 <div class="form-group">
                                            <label for="Password">Password:</label>
                                            <input type="password" class="form-control" name="password" required>
                                        </div>
					</tr>
					<tr>
						<td colspan="2" style="text-align:center"><input type="submit" name="login" value="Login Here"></td>
					</tr>
				</table>
			</form>
			<?php
				if(isset($_POST['login'])){
					include 'config/config.php';
					
					$uname = $_POST['user_name'];
					$pass = $_POST['password'];
					
					$query = "SELECT * FROM admin WHERE user_name = '$uname' AND password = '$pass'";
					$rs = $conn->query($query);
					$num = $rs->num_rows;
					$rows = $rs->fetch_assoc();
					if($num > 0){
						session_start();
						$_SESSION['user_name'] = $rows['user_name'];
						$_SESSION['password'] = $rows['password'];
						echo "<script type = \"text/javascript\">
									alert(\"Login Successful.................\");
									window.location = (\"/admin/home.php\")
									</script>";
					} else{
						echo "<script type = \"text/javascript\">
									alert(\"Login Failed. Try Again................\");
									window.location = (\"home.php\")
									</script>";
					}
				}
			?>
			
	
</body>
</html>
