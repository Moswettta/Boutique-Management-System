<?php
error_reporting(0);
?>
<?php

// config.php (combined with daily_report.php)
$host = 'localhost'; // or your host
$user = 'root'; // your database username
$password = ''; // your database password
$dbname = 'fashion'; // your database name

$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Start session and include necessary files
session_start();
require 'header.php'; // Include header
require 'sidebar.php'; // Include sidebar

// Fetch daily orders
$date = date('Y-m-d');
$query = "SELECT * FROM orders WHERE DATE(order_date) = '$date'";
$result = mysqli_query($conn, $query);
?>

<div class="main-content">
    <h1>Daily Report for <?php echo $date; ?></h1>
    <table class="report-table">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Username</th>
                <th>Delivery Address</th>
                <th>Payment Method</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>Order Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['username']; ?></td>
                    <td><?php echo $row['delivery_address']; ?></td>
                    <td><?php echo $row['payment_method']; ?></td>
                    <td><?php echo number_format($row['total_price'], 2); ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td><?php echo $row['order_date']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<style>
    /* General styling for the body */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4; /* Light gray background */
    }

    /* Header styling */
    header {
            background-color: black;
            color: white;
            padding: 15px 0;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }

    /* Sidebar styling */
    /* Sidebar styles */
        .sidebar {
            background-color: blue;
            color: white;
            padding-top: 20px;
            width: 220px; /* Increased for better visibility */
            height: calc(100vh - 65px); /* Adjust height considering header height */
            float: left; /* Makes the sidebar float left */
            z-index: 1;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 12px 15px; /* Adjusted padding for a more comfortable click area */
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

    /* Main content area */
    .main-content {
        margin-left: 270px; /* Space for sidebar */
        padding: 20px; /* Padding around main content */
        background-color: white; /* White background for main content */
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Light shadow for depth */
    }

    /* Report table styling */
    .report-table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }

    .report-table th, .report-table td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .report-table th {
        background-color: #4CAF50; /* Table header background */
        color: white;
    }

    .report-table tr:hover {
        background-color: #f1f1f1; /* Highlight row on hover */
    }

    /* Responsive design for smaller screens */
    @media (max-width: 768px) {
        .sidebar {
            width: 100%; /* Full width for sidebar on small screens */
            height: auto; /* Auto height */
            float: none; /* Remove float */
        }

        .main-content {
            margin-left: 0; /* Remove margin for main content */
        }
    }
</style>

<?php
// Close the database connection
mysqli_close($conn);
require 'footer.php'; // Include footer
?>
