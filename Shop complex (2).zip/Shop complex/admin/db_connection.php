<?php
// Database configuration
$servername = "localhost"; // Change if your database server is different
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$database = "fashion"; // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Set character set to UTF-8 for better compatibility
$conn->set_charset("utf8");

?>
