<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Students</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/index.css" rel="stylesheet" type="text/css"/>
 
</head>
<header>
    <nav class="navbar navbar" id="navg">
        <div class="col-md-9">
            <h3>
                <a href="admin_lecturers.php"><div class="glyphicon glyphicon-dashboard"></div>
                    FeedBack
                </a>

            </h3>

        </div>
        <div class="col-md-3 col-sm-3">
            <h5>Welcome Administrator| <a href="admin.php"><div class="glyphicon glyphicon-log-out">logout</div></a>
            </h5>
        </div>
        </div>
        </div>
    </nav>
</header>


<?php
	include 'config/config.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM lecs WHERE id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo 'Lecturer has been successfully been Deleted';
	?>
		<meta content="4; index.php" http-equiv="refresh" />
	<?php
	}
?>
