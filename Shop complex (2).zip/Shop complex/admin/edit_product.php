<?php
// Database connection parameters
$host = "127.0.0.1"; // Host
$db_name = "fashion"; // Database name
$username = "root"; // Database username (default for XAMPP)
$password = ""; // Database password (default for XAMPP is empty)

// Create connection
$conn = new mysqli($host, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the product ID is set
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure it's an integer

    // Fetch the product details
    $sql = "SELECT * FROM product WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo "<p>Product not found.</p>";
        exit;
    }

    $product = $result->fetch_assoc();
} else {
    echo "<p>Invalid product ID.</p>";
    exit;
}
?>

<!-- Include Header -->
<?php include 'header.php'; ?>

<div class="container">
    <!-- Include Sidebar -->
    <?php include 'sidebar.php'; ?>

    <div class="content">
        <h2>Edit Product</h2>
        <form action="update_product.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>">

            <div class="form-group">
                <label for="name">Product Name:</label>
                <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="size">Size:</label>
                <input type="text" name="size" id="size" value="<?php echo htmlspecialchars($product['size']); ?>" required>
            </div>
             <div class="form-group">
                <label for="size">Quantity:</label>
                <input type="number" name="sum" id="sum" value="<?php echo htmlspecialchars($product['sum']); ?>" required>
            </div>

            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" name="price" id="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>
            </div>
            <div class="form-group">
                <label for="image">Current Image:</label>
                <div class="image-preview">
                    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="new_image">Change Image (optional):</label>
                <input type="file" name="new_image" id="new_image" accept="image/*">
                <small>(Optional) Upload a new image file.</small>
            </div>
            <button type="submit" class="submit-button">Update Product</button>
        </form>
    </div>
</div>

<?php
// Close connection
$conn->close();
?>

<style>
    .container {
        display: flex;
    }
    .sidebar {
        width: 200px;
        background: #343a40; /* Match sidebar color with your theme */
        color: #fff;
        padding: 15px;
        box-shadow: 2px 2px 5px rgba(0,0,0,0.3);
    }
    .sidebar a {
        color: #fff;
        text-decoration: none;
        display: block;
        margin: 10px 0;
    }
    .content {
        flex: 1;
        padding: 20px;
        background: #f4f4f4; /* Light background for the content area */
    }
    .form-group {
        margin-bottom: 15px;
    }
    .image-preview {
        margin: 10px 0;
        max-width: 100%; /* Prevent overflow */
        overflow: hidden; /* Ensure the image doesn't overflow the container */
    }
    .image-preview img {
        width: 100%; /* Full width of the container */
        height: auto; /* Maintain aspect ratio */
        border-radius: 5px; /* Add some border radius for styling */
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    }
    label {
        display: block;
        margin-bottom: 5px;
    }
    input[type="text"],
    input[type="number"],
    input[type="file"] {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
    }
    .submit-button {
        background-color: #0073e6; /* Submit button color */
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .submit-button:hover {
        background-color: #005bb5; /* Darker shade on hover */
    }
</style>

</body>
</html>
