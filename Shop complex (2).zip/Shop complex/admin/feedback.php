﻿<?php
					Session_start();
					require 'config/config.php';
?>
    <!DOCTYPE HTML>
<HTML lang="en">
<head>
	<title>Rabuor Complex</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/bootstrap.min.js"></script>
	<link href="bootstrap.css" rel='stylesheet' type='text/css' />
	<link rel="stylesheet" href='css/styles.css' type='text/css' media="all"/>
	  <script>tinymce.init({ selector:'textarea' });</script>
<script type="text/javascript">
		function sureToApprove(id){
			if(confirm("Are you sure you want to delete this product?")){
				window.location.href ='delete_prod.php?id='+id;
			}
		}
	</script>
		</head>
		<body>
		<!-- main container starts her -->
	<div class="main_wrapper">
	<!-- header starts her -->
<header>
    <div class="jumbotron">
        <div class="col-md-4">
            <h3>
            <div class="glyphicon glyphicon-dashboard"></div>
                Rabuor Complex

            </h3>

        </div>
        <div class="col-md-8 col-sm-8">
         <a href="admin_login.php"><div class="glyphicon glyphicon-log-out">logout</div></a>

                    <a href="add_hotel.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-plus">Add Mens' Wear</div></button></a>
                                        <a href="add_women.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-plus">Add Womens' Wear</div></button></a>
                                                            <a href="add_hotel.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-plus">Add Kids' Wear</div></button></a>
                                                                                <a href="order.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-stats">Reports</div></button></a>
                                                                                      <a href="/Fashion/index.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-log-out">Log Out</div></button></a>
                    
<!-- MENU SECTION END-->
</div></div>    
<div class="content-wrapper">
        <div class="container">
             <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Feedback Section</h1>
                    </div>
                </div>
                
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3><strong>The Feedback Sent By Users In The System.</strong></h3>
                        </div>
                        
                    </div>
				   <?php
				$db_host = 'localhost'; // Nama Server
				$db_user = 'root'; // User Server
				$db_pass = ''; // Password Server
				$db_name = 'fashion'; // Nama Database
				 
				$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
				if (!$conn) {
					die ('Fail to connect to MySQL: ' . mysqli_connect_error());   
				}
				 
				$sql = 'SELECT * 
						FROM feedback';
						 
				$query = mysqli_query($conn, $sql);
				 
				if (!$query) {
					die ('SQL Error: ' . mysqli_error($conn));
				}
				 
				echo '
						<div class="table-responsive">
						<table class = "table table-hover" >
						<thead>
							<tr>
								<th>#</th>
								<th>Username</th>
								<th>Email</th>
								<th>Subject</th>
								<th>Feedback</th>
								<th>Date & Time sent</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
						</div>';
						 
				while ($row = mysqli_fetch_array($query))
				{
					echo '<tr class="success">
						
							<td>'.$row['id'].'</td>
							<td>'.$row['user_name'].'</td>
							<td>'.$row['email'].'</td>
							<td>'.$row['subject'].'</td>
							<td class="right">'.$row['body'].'</td>
							 <td>'.$row['time'].'</td>
							<td>'.'<button type="button" class = "btn btn-primary" data-toggle="modal" data-target="#myModal" >Reply</button>'.'</td>
						</tr>';
				}
				echo '
					</tbody>
					<button type="submit" onclick="window.print()" class="btn btn-success"><span class="glyphicon glyphicon-print"></span>Print</button>
				</table>';
				 
				// Should we need to run this? read section VII
				mysqli_free_result($query);
				 
				// Should we need to run this? read section VII
				mysqli_close($conn);
				  ?> 
   
   </div>
</div>
    <!-- CONTENT-WRAPPER SECTION END-->
	<?php
					
					if(isset($_POST['username'])&& isset($_POST['email'])&& isset($_POST['feedback'])){
					
					$username=$_POST['username'];
					$email =$_POST['email'];
					//$subject= ;
					$feedback=$_POST['feedback'];
					

					$sql="INSERT INTO admin_replies VALUES('','$username', '$email', '$subject', '$feedback', NOW())";
					if($con->query($sql)==TRUE){
					
					echo "<script type = \"text/javascript\">
					alert(\"Your feedback has been submitted successfully..\")
					window.location = (\"feedback.php\");</script>";
					
					}else{
					echo "<script> alert('Connection Failed!')</script>";
					}
					}
					
			?>
	<!--  Modals-->
                        <div class="panel-body">
                            
                           <div class="modal fade" id="myModal" role="dialog">
								 <div class="modal-dialog">
								
								  <!-- Modal content-->
								  <div class="modal-content">
									<div class="modal-header" style="padding:25px 40px;">
									  <button type="button" class="close" data-dismiss="modal">&times;</button>
									  <h4> Reply</h4>
									</div>
									<div class="modal-body" style="padding:40px 50px;">
									  <form role="form" method = "post">
										<label for = "username"><span class="glyphicon glyphicon-user"></span> Enter username : </label>
									<input type="text" name = "username" class="form-control"  placeholder="Enter username" required>
									
									<label for = "email"><span class="glyphicon glyphicon-envelope"></span> Enter Email : </label>
									<input type="text" name = "email" class="form-control"  placeholder="Enter email" required>
									
									<label for = "feedback" ><span class="glyphicon glyphicon-edit"></span> Enter Message: </label>
									<textarea rows="9" name = "feedback" class="form-control" placeholder="Enter message" required></textarea>
										
										  <input type="submit" name = "bttlogin" class="btn btn-success"></input>
									  </form>
									  
									</div>
									<div class="modal-footer">
									  <button type="submit" class="btn btn-danger btn-default pull-right" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
									</div>
								  </div>
								  
								</div>
							</div>
                        </div>
                    
                     <!-- End Modals-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2023 Rabuor Shop | By : <a href="#" target="_blank">Wilfred</a>
                </div>

            </div>
        </div>
    </footer>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
	<script src="js/jquery-1.12.3.min.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
