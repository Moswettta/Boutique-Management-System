<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Amboseli Park</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
     <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<style>
				body {
					font-family: "segoe ui";
				}
				table {
					margin:auto;
					margin-top: 15px;
					border-collapse: collapse;
				}
				th, td {
					border: 1px solid #dadada;
					padding: 5px 10px;
				}
				th {
					background-color: #f3f3f3;
				}
				td{
					text-align: left;
				}
				
			</style>
	
</head>
<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <strong>Email: </strong>info@amboselipark.com
                    &nbsp;&nbsp;
                    <strong>Support: </strong>+254-20-123-2113
                </div>

            </div>
        </div>
    </header>
    <!-- HEADER END-->
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
          <div class="navbar-header">
		  
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"><h3> AMBOSELI ADMIN <h3></a>

            </div> 

           
        </div>
    </div>
    <!-- LOGO HEADER END-->
   <section class="menu-section">
        <div class="container-fluid">
            <div class="row">
			
                <div class="col-md-12">
				 
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="index.php">Dashboard</a></li>
                            <li class="dropdown" >
                               <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                User Reports <b class="caret"></b>
                               </a>
                                  <ul class="dropdown-menu">
                                  <li><a href="Users.php">Registered Users</a></li>
                                  
								  <li class="divider"></li>
                                  <li><a href="user_booking.php">User Bookings</a></li>
                                  </ul>
                            </li>
							
							<li><a href="accomodation_add.php">Accomodation</a></li>
							<li class="dropdown" >
                               <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                Accomodation Reports <b class="caret"></b>
                               </a>
                                  <ul class="dropdown-menu">
                                  <li><a href="accomodation.php">Camps & Lodges</a></li>
                                  <li class="divider"></li>
                                  <li><a href="camp_booking.php">Camps & Lodges Booking</a></li>
                                  </ul>
                            </li>
							
							<li class="dropdown" >
                               <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                Transport Reports <b class="caret"></b>
                               </a>
                                  <ul class="dropdown-menu">
                                  <li><a href="transport.php">Transport</a></li>
                                  <li class="divider"></li>
                                  <li><a href="trans_booking.php">Transport Booking</a></li>
                                  </ul>
                            </li>
							<li><a href="add.php">Add Users</a></li>
							
							<li class="dropdown" >
                               <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                Payments Reports <b class="caret"></b>
                               </a>
                                  <ul class="dropdown-menu">
                                  <li><a href="payments.php">Payments</a></li>
                                  <li class="divider"></li>
                                  <li><a href="table.php">Booking</a></li>
                                  </ul>
                            </li>
							<li class="dropdown" >
                               <a class="menu-top-active" href="#" class="dropdown-toggle" data-toggle="dropdown">
                                Feedback Reports <b class="caret"></b>
                               </a>
                                   <ul class="dropdown-menu">
                                  <li><a href="Feedback.php">Feedback Received</a></li>
                                  <li class="divider"></li>
                                  <li><a href="feedback_replies.php">Feedback Sent</a></li>
                                  </ul>
                                  </ul>
                            </li>
                            

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- MENU SECTION END-->

	<div class="content-wrapper">
        <div class="container">
             <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Feedback Replies</h1>
                    </div>
                </div>
                
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3><strong>Admin Feedback Replies.</strong></h3>
                        </div>
                        
                    </div>
				   <?php
				$db_host = 'localhost'; // Nama Server
				$db_user = 'root'; // User Server
				$db_pass = ''; // Password Server
				$db_name = 'amboseli'; // Nama Database
				 
				$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
				if (!$conn) {
					die ('Fail to connect to MySQL: ' . mysqli_connect_error());   
				}
				 
				$sql = 'SELECT id, username, user_email, admin_reply, reply_date 
						FROM admin_replies';
						 
				$query = mysqli_query($conn, $sql);
				 
				if (!$query) {
					die ('SQL Error: ' . mysqli_error($conn));
				}
				 
				echo '
						<div class="table-responsive">
						<table class = "table table-hover" >
						<thead>
							<tr>
								<th>#</th>
								<th>Username</th>
								<th>User Email</th>
								<th>Admin Reply</th>
								<th>Reply Date & Time </th>
								
							</tr>
						</thead>
						<tbody>
						</div>';
						 
				while ($row = mysqli_fetch_array($query))
				{
					echo '<tr class="success">
						
							<td>'.$row['id'].'</td>
							<td>'.$row['username'].'</td>
							<td>'.$row['user_email'].'</td>
							<td class="right">'.$row['admin_reply'].'</td>
							<td>'.$row['reply_date'].'</td>
							
						</tr>';
				}
				echo '
					</tbody>
					<button type="submit" onclick="window.print()" class="btn btn-success"><span class="glyphicon glyphicon-print"></span>Print</button>
				</table>';
				 
				// Should we need to run this? read section VII
				mysqli_free_result($query);
				 
				// Should we need to run this? read section VII
				mysqli_close($conn);
				  ?> 
   
   </div>
</div>
	
    <!-- CONTENT-WRAPPER SECTION END-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2017 Amboseli Park | By : <a href="#" target="_blank">Alice</a>
                </div>

            </div>
        </div>
    </footer>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
