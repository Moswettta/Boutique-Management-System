<?php
session_start(); // Start the session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link your CSS file here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* Header styling */
        header {
            background-color: #0073e6; /* Blue background for header */
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0; /* Remove default margin */
        }

        .admin-name {
            font-weight: bold;
            margin-right: 20px; /* Add space to the right */
        }

        /* Navigation styling */
        nav {
            margin-left: 20px; /* Add some margin to the left of the nav */
        }

        nav a {
            text-decoration: none;
            color: white;
            margin: 0 15px;
            font-size: 16px;
        }

        nav a:hover {
            text-decoration: underline; /* Underline on hover for links */
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
        <div class="admin-name">
            <?php
            // Display the admin's name if set
            if (isset($_SESSION['admin_name'])) {
                echo "Welcome, " . htmlspecialchars($_SESSION['admin_name']);
            }
            ?>
        </div>
        <nav>
            <a href="home.php">Home</a>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="logout.php">Log Out</a> <!-- Assuming you have a logout script -->
        </nav>
    </header>
</body>
</html>
