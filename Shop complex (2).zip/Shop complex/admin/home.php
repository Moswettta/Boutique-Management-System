<?php
error_reporting(0); // Suppresses all error reporting
// Database connection
$conn = new mysqli('localhost', 'root', '', 'fashion');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data
$userCount = $conn->query("SELECT COUNT(*) as total FROM user")->fetch_assoc()['total'];
$orderCount = $conn->query("SELECT COUNT(*) as total FROM orders")->fetch_assoc()['total'];
$productCount = $conn->query("SELECT COUNT(*) as total FROM product")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Stedmark</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5; /* Lighter background for a more modern look */
            color: #333;
        }

        /* Header styles */
        header {
            background-color: #1c1c1e; /* Darker header for contrast */
            color: white;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            position: relative;
            z-index: 1;
        }

        header h1 {
            margin: 0;
            font-size: 26px; /* Increased font size for impact */
            font-weight: 700; /* Bolder weight for emphasis */
        }

        /* Sidebar styles */
        .sidebar {
            background-color: #242426; /* Dark sidebar for a modern feel */
            color: white;
            padding-top: 20px;
            width: 220px;
            height: calc(100vh - 65px);
            float: left;
            z-index: 1;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2); /* Added shadow for depth */
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            transition: background-color 0.3s, padding-left 0.3s; /* Smooth padding transition */
            position: relative;
        }

        .sidebar a:hover {
            background-color: #575757;
            padding-left: 20px; /* Slight padding effect on hover */
        }

        /* Content area */
        .content {
            margin-left: 240px;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }

        /* Card container */
        .card-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        /* Card styles */
        .card {
            background: linear-gradient(145deg, #ffffff, #e6e6e6); /* Gradient background for cards */
            border-radius: 15px;
            padding: 20px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.1), -5px -5px 15px rgba(255, 255, 255, 0.8); /* Inner shadow for depth */
            flex: 1;
            margin: 0 10px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s; /* Smooth scaling and shadow transition */
        }

        .card:hover {
            transform: translateY(-5px); /* Slight lift effect on hover */
            box-shadow: 10px 10px 20px rgba(0, 0, 0, 0.2), -10px -10px 20px rgba(255, 255, 255, 0.9);
        }

        .card h3 {
            margin-bottom: 10px;
            font-size: 20px;
            color: #333;
        }

        .card p {
            font-size: 36px; /* Increased font size for emphasis */
            font-weight: 700; /* Bolder weight for visibility */
            color: #007bff; /* Primary color for numbers */
        }

        /* Button styles */
        .btn {
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            color: white;
            background-color: #007bff;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.2s;
        }

        .btn:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .btn-default {
            background-color: #6c757d;
        }

        .btn-default:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="main_wrapper">
        <header class="header">
            <?php include 'header.php'; ?>
        </header>

        <div class="container-fluid">
            <?php include 'sidebar.php'; ?>

            <div class="content">
                <h2>Dashboard</h2>

                <div class="card-container">
                    <div class="card card-users">
                        <h3>Users</h3>
                        <p><?php echo $userCount; ?></p>
                    </div>
                    <div class="card card-orders">
                        <h3>Orders</h3>
                        <p><?php echo $orderCount; ?></p>
                    </div>
                    <div class="card card-products">
                        <h3>Products</h3>
                        <p><?php echo $productCount; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
