var date = new Date();
var stringdate = date.toUTCString();
document.getElementById("date").innerHTML = stringdate;

