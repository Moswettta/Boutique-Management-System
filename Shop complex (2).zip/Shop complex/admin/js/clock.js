/**
 * Created by Gerrard on 2/5/2017.
 */
var clock = document.getElementById("clock");
function displayTime() {
    var time = new Date();
    var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var hour = time.getHours().toString();
    var minute = time.getMinutes().toString();
    var seconds = time.getSeconds().toString();
     if(hour.length < 2)
     {
         hour = '0' + hour;
     }
    if(minute.length < 2)
    {
        minute = '0' + minute;
    }
    if(seconds.length < 2)
    {
        seconds = '0' + seconds;
    }

var clockStr = days[time.getDay()]+" "+hour + ":" +minute + ":" +seconds;
     clock.textContent = clockStr;
}

setInterval(displayTime,1000);