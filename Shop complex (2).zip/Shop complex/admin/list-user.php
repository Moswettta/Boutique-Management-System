

<?php 
	require 'db.php';
 		
 		$sqltran = mysqli_query($con, "SELECT * FROM orderss ")or die(mysqli_error($con));
		$arrVal = array();
 		
		$i=1;
 		while ($rowList = mysqli_fetch_array($sqltran)) {
 								 
						$name = array(
								'num' => $rowList['id'],
 	 		 	 				'item'=> $rowList['item'],
	 		 	 				'price'=> $rowList['price'],
	 		 	 				'quantity'=> $rowList['quantity'],
	 		 	 				'user'=> $rowList['user'],
	 		 	 				'date'=> $rowList['date'],



 	 		 	 			);		


							array_push($arrVal, $name);	
			$i++;			
	 	}
	 		 echo  json_encode($arrVal);		
 

	 	mysqli_close($con);
?>   
 