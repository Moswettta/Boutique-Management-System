<!DOCTYPE HTML>
<HTML lang="en">
<head>
	<title>Rabuor Complex</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery-1.12.3.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link href="bootstrap.css" rel='stylesheet' type='text/css' />
	<link rel="stylesheet" href='css/styles.css' type='text/css' media="all"/>
	  <script>tinymce.init({ selector:'textarea' });</script>
<script type="text/javascript">
		function sureToApprove(id){
			if(confirm("Are you sure you want to delete this product?")){
				window.location.href ='delete_prod.php?id='+id;
			}
		}
	</script>
		</head>
		<body>
		<!-- main container starts her -->
	<div class="main_wrapper">
	<!-- header starts her -->
<header>
    <div class="jumbotron">
        <div class="col-md-4">
            <h3>
            <div class="glyphicon glyphicon-dashboard"></div>
                Rabuor Complex

            </h3>

        </div>
        <div class="col-md-8 col-sm-8">
         <a href="admin_login.php"><div class="glyphicon glyphicon-log-out">logout</div></a>

                    <a href="add_hotel.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-plus">Add Mens' Wear</div></button></a>
                                        <a href="add_women.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-plus">Add Womens' Wear</div></button></a>
                                                            <a href="add_hotel.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-plus">Add Kids' Wear</div></button></a>
                                                                                <a href="order.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-stats">Reports</div></button></a>
                                                                                      <a href="/Fashion/index.php"> <button type="button" class="btn btn-default"><div class="glyphicon glyphicon-log-out">Log Out</div></button></a>
                    

<br><br><br>

<form action="order.php" method="post">
From: <input name="from" type="date" class="tcal"/>
To: <input name="to" type="date" class="tcal"/>
<input name="send" type="submit" value="Search" />
</form><br />
<?php
$con = mysqli_connect("localhost","root","","fashion");
 // Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
 if(isset($_POST['send'])){
    
$a=$_POST['from'];
$b=$_POST['to'];
       
$result2 = mysqli_query($con,"SELECT count(quantity) FROM orderss where date BETWEEN '$a' AND '$b'");
    while($row = mysqli_fetch_array($result2))
    {
       
		$p=$row['count(quantity)'];
        echo "Number of Orders :" .($p)."<br>";


    }}
?>
        </h5>
        </div>
    </div>
</header>
	</div>

<div class="col-xs-2">

        



</div>
<div class="col-lg-10">
	<table class="table table-bordered table-hover">
    <thead>
      <tr>
		<th>Item</th>
        <th>Quantity</th>
		<th>Price</th>
		<th>User</td>
		<th>Date</th>
      </tr>
    </thead>
<tbody>
<?php
		include 'config/config.php';
						$sel = "SELECT * FROM orderss";
						$rs = $conn->query($sel);
						while($row = $rs->fetch_assoc()){
	?>
	<tr class="record">
		<td><?php echo $row['item']; ?></td>
		<td><?php echo $row['quantity']; ?></td>
		<td><?php echo $row['price']; ?></td>
		<td><?php echo $row['user']; ?></td>
		<td><?php echo $row['date']; ?></td>


	<?php
		}
	?>
	<button type="submit" onclick="window.print()" class="btn btn-success"><span class="glyphicon glyphicon-print"></span>Print</button>	

</table>
</div>
