<?php
// Include database connection file
include 'db_connection.php'; // Adjust the path as necessary

// Handle form submissions for updating order status or deleting
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $orderId = $_POST['order_id'];
    $action = $_POST['action'];

    if ($action === 'approve') {
        $query = "UPDATE orders SET status = 'Approved' WHERE id = ?";
    } elseif ($action === 'delete') {
        // Prepare delete query
        $query = "DELETE FROM orders WHERE id = ?";
    } else {
        $query = "UPDATE orders SET status = 'Pending' WHERE id = ?";
    }

    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("i", $orderId);
        $stmt->execute();
        $stmt->close();
    }
}

// Fetch orders along with their items
$sql = "
    SELECT o.id AS order_id, o.username, o.delivery_address, o.payment_method, o.total_price, o.status, 
           oi.item_name, oi.quantity
    FROM orders o
    LEFT JOIN order_items oi ON o.id = oi.order_id
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Management</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Basic Reset */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9; /* Light background for better readability */
        }

        /* Header styles */
        header {
            background-color: #007bff; /* Blue header */
            color: white;
            padding: 10px 0;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
            font-size: 24px; /* Increased for better visibility */
        }

        /* Sidebar styles */
        .sidebar {
            background-color: #333; /* Dark sidebar */
            color: white;
            padding-top: 10px;
            width: 200px;
            height: 100vh;
            float: left;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #444; /* Slightly lighter hover effect */
        }

        /* Content area */
        .content {
            margin-left: 220px;
            padding: 20px; /* Increased padding for better spacing */
            max-width: 800px;
        }

        /* Table styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px; /* Added margin for spacing */
        }

        th, td {
            padding: 10px; /* Added padding for readability */
            text-align: left;
            border-bottom: 1px solid #ccc; /* Simple border for table rows */
        }

        th {
            background-color: #007bff; /* Header background color */
            color: white; /* Header text color */
        }

        /* Button styles */
        .btn {
            padding: 6px 12px;
            margin: 2px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn[type="submit"] {
            background-color: #28a745; /* Green for approve */
            color: white;
        }

        .btn[type="submit"]:hover {
            background-color: #218838; /* Darker green on hover */
        }

        .btn.btn-default {
            background-color: #dc3545; /* Red for delete */
        }

        .btn.btn-default:hover {
            background-color: #c82333; /* Darker red on hover */
        }
    </style>
</head>
<body>
    <header>
       <?php include 'header.php'; ?>
    </header>

    <div class="sidebar">
        <?php include 'sidebar.php'; ?> <!-- Sidebar links will be included here -->
    </div>

    <div class="content">
        <h2>Manage Orders</h2>

        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Username</th>
                    <th>Delivery Address</th>
                    <th>Payment Method</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Items</th>
                    <th>Quantities</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Variable to store the previous order ID
                $previousOrderId = null;

                while ($row = $result->fetch_assoc()):
                    // Display order details only for the first item of each order
                    if ($row['order_id'] != $previousOrderId):
                        ?>
                        <tr>
                            <td><?php echo $row['order_id']; ?></td>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo htmlspecialchars($row['delivery_address']); ?></td>
                            <td><?php echo htmlspecialchars($row['payment_method']); ?></td>
                            <td><?php echo htmlspecialchars($row['total_price']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                            <td><?php echo htmlspecialchars($row['item_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                            <td>
                                <form method="POST" action="">
                                    <input type="hidden" name="order_id" value="<?php echo $row['order_id']; ?>">
                                    <button class="btn" type="submit" name="action" value="approve">Approve</button>
                                    <button class="btn btn-default" type="submit" name="action" value="delete" onclick="return confirm('Are you sure you want to delete this order?');">Delete</button>
                                    <button class="btn" type="submit" name="action" value="pending">Pending</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                        $previousOrderId = $row['order_id'];
                    else:
                        ?>
                        <tr>
                            <td colspan="6"></td>
                            <td><?php echo htmlspecialchars($row['item_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                            <td></td>
                        </tr>
                    <?php endif; ?>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <?php $conn->close(); ?>
</body>
</html>
