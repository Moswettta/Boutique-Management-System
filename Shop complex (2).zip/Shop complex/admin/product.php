<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Stedmark - View Products</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* Header styles */
        header {
            background-color: #007bff;
            color: white;
            padding: 15px 0;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }

        /* Sidebar styles */
        .sidebar {
            background-color: #333;
            color: white;
            padding-top: 20px;
            width: 200px;
            height: calc(100vh - 65px); /* Adjust height considering header height */
            position: relative; /* Changed from fixed to relative */
            float: left; /* Makes the sidebar float left */
            z-index: 1;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        /* Content area */
        .content {
            margin-left: 220px; /* Adjusted this to account for sidebar width */
            padding: 20px;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        img {
            width: 80px;
            height: 60px;
            object-fit: cover;
        }

        /* Button styles */
        .btn {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            text-decoration: none;
        }

        .btn-success {
            background-color: #28a745;
            color: white;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-success:hover, .btn-danger:hover {
            opacity: 0.9;
        }
    </style>

    <script type="text/javascript">
        function sureToApprove(id) {
            if (confirm("Are you sure you want to delete this product?")) {
                window.location.href = '?delete=' + id; // Redirecting to delete
            }
        }
    </script>
</head>
<body>

<!-- Include Header -->
<?php include 'header.php'; ?>

<!-- Include Sidebar -->
<?php include 'sidebar.php'; ?>

<!-- Main content area starts here -->
<div class="content">
    <h2>Available Products</h2>
    <table>
        <thead>
            <tr>
                <th>Wear</th>
                <th>Wear Size</th>
                <th>Wear Price</th>
                    <th>Quantity</th>

                <th>Image</th>
                <th>Content Management</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include 'config/config.php';

                // Handle product deletion
                if (isset($_GET['delete'])) {
                    $id = intval($_GET['delete']);
                    $deleteQuery = "DELETE FROM product WHERE id = ?";
                    
                    $stmt = $conn->prepare($deleteQuery);
                    $stmt->bind_param("i", $id);
                    
                    if ($stmt->execute()) {
                        echo "<script>alert('Product deleted successfully.');</script>";
                    } else {
                        echo "<script>alert('Error deleting product: " . $conn->error . "');</script>";
                    }

                    $stmt->close();
                }

                // Fetch products from the database
                $sel = "SELECT * FROM product";
                $rs = $conn->query($sel);
                while ($row = $rs->fetch_assoc()) {
            ?>
            <tr class="record">
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['size']); ?></td>
                <td><?php echo htmlspecialchars($row['price']); ?></td>
                 <td><?php echo htmlspecialchars($row['sum']); ?></td>

                <td><img src="images/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" /></td>
                <td>
                    <a href="update.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">
                        Edit
                    </a>
                    <a href="javascript:sureToApprove('<?php echo $row['id']; ?>')" class="btn btn-danger btn-sm">
                        Delete
                    </a>
                </td>
            </tr>
            <?php
                }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
