<div class="sidebar">
    <a href="home.php">Dashboard</a>
    <div class="dropdown">
        <a href="javascript:void(0);" class="dropdown-heading" onclick="toggleDropdown()">Products</a>
        <div class="dropdown-links" id="productLinks" style="display: none;">
            <a href="add_product.php">Add Product</a> <!-- Clickable link -->
            <a href="product.php">View Products</a> <!-- Clickable link -->
        </div>
    </div>
    <a href="orders.php">Orders</a>
    <a href="users.php">Users</a>
    <div class="dropdown">
        <a href="javascript:void(0);" class="dropdown-heading" onclick="toggleDropdownReports()">Reports</a>
        <div class="dropdown-links" id="reportLinks" style="display: none;">
            <a href="daily_report.php">Daily Report</a>
            <a href="monthly_report.php">Monthly Report</a>
            <a href="yearly_report.php">Yearly Report</a>
        </div>
    </div>
    <button onclick="location.href='admin_login.php'">Logout</button>
</div>

<script type="text/javascript">
    function toggleDropdown() {
        var dropdownLinks = document.getElementById("productLinks");
        if (dropdownLinks.style.display === "none") {
            dropdownLinks.style.display = "block"; // Show the links
        } else {
            dropdownLinks.style.display = "none"; // Hide the links
        }
    }

    function toggleDropdownReports() {
        var dropdownLinks = document.getElementById("reportLinks");
        if (dropdownLinks.style.display === "none") {
            dropdownLinks.style.display = "block"; // Show the links
        } else {
            dropdownLinks.style.display = "none"; // Hide the links
        }
    }
</script>
