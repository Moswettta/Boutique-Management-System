<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Stedmark - Update Product</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #007bff;
            color: white;
            padding: 15px 0;
            text-align: center;
            position: relative;
            z-index: 1;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }
        .sidebar {
            background-color: #333;
            color: white;
            padding-top: 20px;
            width: 200px;
            height: calc(100vh - 65px);
            position: relative;
            float: left;
            z-index: 1;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: #575757;
        }
        .content {
            margin-left: 220px;
            padding: 20px;
        }
        form {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"],
        input[type="number"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        img {
            width: 80px;
            height: 60px;
            object-fit: cover;
            margin-bottom: 10px;
        }
        .btn {
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            color: white;
            background-color: #007bff;
            border-radius: 5px;
        }
        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<!-- Include Header -->
<?php include 'header.php'; ?>

<!-- Include Sidebar -->
<?php include 'sidebar.php'; ?>

<!-- Main content area starts here -->
<div class="content">
    <h2>Update Product</h2>
    
    <?php
        include 'config/config.php';

        // Fetch product details based on ID
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $query = "SELECT * FROM product WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $product = $result->fetch_assoc();

            if (!$product) {
                echo "<p>Product not found.</p>";
                exit;
            }
        }

        // Handle form submission for updating the product
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = htmlspecialchars($_POST['name']);
            $size = htmlspecialchars($_POST['size']);
            $price = intval($_POST['price']);  // Ensure price is an integer
            $sum = intval($_POST['sum']);  // Ensure sum is an integer
            $image = $_FILES['image']['name'];
            $uploadDir = 'images/';
            $uploadFile = $uploadDir . basename($image);

            // If a new image is uploaded, update the image; otherwise, retain the old image
            if (!empty($image)) {
                $updateQuery = "UPDATE product SET name = ?, size = ?, price = ?, image = ?, sum = ? WHERE id = ?";
                $stmt = $conn->prepare($updateQuery);
                $stmt->bind_param("sssisi", $name, $size, $price, $image, $sum, $id); // Fixed here
                $moveFile = move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile);
            } else {
                $updateQuery = "UPDATE product SET name = ?, size = ?, price = ?, sum = ? WHERE id = ?";
                $stmt = $conn->prepare($updateQuery);
                $stmt->bind_param("ssssi", $name, $size, $price, $sum, $id); // Fixed here
                $moveFile = true; // No new file to move
            }

            if ($stmt->execute() && $moveFile) {
                echo "<script>alert('Product updated successfully.');</script>";
            } else {
                echo "<script>alert('Error updating product: " . $conn->error . "');</script>";
            }

            $stmt->close();
        }
    ?>

    <form action="" method="post" enctype="multipart/form-data">
        <label for="name">Wear Name</label>
        <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>

        <label for="size">Wear Size</label>
        <input type="text" name="size" id="size" value="<?php echo htmlspecialchars($product['size']); ?>" required>

        <label for="price">Wear Price</label>
        <input type="number" name="price" id="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>

        <label for="quantity">Quantity</label>
        <input type="number" name="sum" id="sum" value="<?php echo htmlspecialchars($product['sum']); ?>" required>

        <label for="image">Current Image</label>
        <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="Current Image" />

        <label for="image">Upload New Image (Optional)</label>
        <input type="file" name="image" id="image">

        <button type="submit" class="btn">Update Product</button>
    </form>
</div>

</body>
</html>
