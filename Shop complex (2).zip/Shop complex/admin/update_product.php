<?php
// Database connection parameters
$host = "127.0.0.1"; // Host
$db_name = "fashion"; // Database name
$username = "root"; // Database username (default for XAMPP)
$password = ""; // Database password (default for XAMPP is empty)

// Create connection
$conn = new mysqli($host, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize input
    $id = intval($_POST['id']);
    $name = trim($_POST['name']);
    $size = trim($_POST['size']);
    $price = floatval($_POST['price']);
    $sum = floatval($_POST['sum']);
    $new_image = $_FILES['new_image'];

    // Prepare the SQL statement
    $sql = "UPDATE product SET name = ?, size = ?, price = ?";

    // Check if a new image is uploaded
    if ($new_image['error'] === UPLOAD_ERR_OK) {
        // Image upload directory
        $upload_dir = 'admin/images/';
        
        // Validate and upload new image
        $image_name = basename($new_image['name']);
        $image_path = $upload_dir . $image_name;
        $image_file_type = strtolower(pathinfo($image_path, PATHINFO_EXTENSION));

        // Check if the uploaded file is an image
        $check = getimagesize($new_image['tmp_name']);
        if ($check === false) {
            echo "File is not an image.";
            exit;
        }

        // Move the uploaded file to the desired directory
        if (move_uploaded_file($new_image['tmp_name'], $image_path)) {
            $sql .= ", image = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssds", $name, $size, $price, $image_name);
        } else {
            echo "Error uploading the image.";
            exit;
        }
    } else {
        // If no new image is uploaded, prepare the statement without the image field
        $stmt = $conn->prepare($sql . " WHERE id = ?");
        $stmt->bind_param("ssd", $name, $size, $price, $id);
    }

    // Execute the statement
    if ($stmt->execute()) {
        echo "Product updated successfully.";
    } else {
        echo "Error updating product: " . $conn->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Redirect back to the edit page or another page
    header("Location: edit_product.php?id=" . $id);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Product</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>
    <h1>Update Product</h1>
    <p><a href="admin_dashboard.php">Go back to the dashboard</a></p>
</body>
</html>
