<!DOCTYPE HTML>
<HTML lang="en">
<head>
    <title>Stedmark</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Custom Internal CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .main_wrapper {
            width: 100%;
            margin: 0 auto;
        }

        .jumbotron {
            background-color: #0073e6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        h3 {
            margin: 0;
        }

        h5 {
            margin: 0;
            text-align: right;
            padding-top: 10px;
        }

        .container-fluid {
            display: flex;
        }

        /* Sidebar Styling */
        .sidebar {
            background-color: #343a40;
            padding: 20px;
            height: 100vh;
            color: white;
            width: 20%;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            margin-bottom: 15px;
        }

        .sidebar button {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #0073e6;
            color: white;
            font-size: 16px;
            cursor: pointer;
            text-align: left;
        }

        .sidebar button:hover {
            background-color: #005bb5;
        }

        /* Main Content Area */
        .content {
            width: 80%;
            padding: 20px;
            background-color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #0073e6;
            color: white;
        }

        td img {
            height: 60px;
            width: 80px;
        }

        .btn {
            padding: 8px 12px;
            color: white;
            text-decoration: none;
            display: inline-block;
            border-radius: 5px;
            text-align: center;
        }

        .btn-success {
            background-color: #28a745;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .btn-success:hover, .btn-danger:hover {
            opacity: 0.9;
        }

        .btn-sm {
            font-size: 14px;
            padding: 6px 10px;
        }
    </style>

    <script src="js/jquery-1.12.3.min.js"></script>
    <script>tinymce.init({ selector: 'textarea' });</script>
    <script type="text/javascript">
        function sureToApprove(id) {
            if (confirm("Are you sure you want to delete this product?")) {
                window.location.href = 'delete_prod.php?id=' + id;
            }
        }
    </script>
</head>
<body>
    <!-- Main container starts here -->
    <div class="main_wrapper">
        <!-- Header starts here -->
        <header>
            <div class="jumbotron">
                <div style="display: inline-block;">
                    <h3>
                        <div class="glyphicon glyphicon-dashboard"></div> Rabuor Complex
                    </h3>
                </div>
                <div style="float: right;">
                    <h5>Welcome Administrator</h5>
                </div>
            </div>
        </header>

        <!-- Container for sidebar and content -->
        <div class="container-fluid">
            <!-- Sidebar starts here -->
            <div class="sidebar">
                <!-- View Products Button -->
<a href="view_products.php">
    <button type="button">View Products</button>
</a>

<!-- Add Womens' Wear Button -->
<a href="add_women.php"> 
    <button type="button">Add Womens' Wear</button>
</a>

                <a href="add_kids.php">
                    <button type="button">Add Kids' Wear</button>
                </a>
                <a href="order.php">
                    <button type="button">Reports</button>
                </a>
                <a href="feedback.php">
                    <button type="button">Feedback</button>
                </a>
                <a href="/Fashion/index.php">
                    <button type="button">Log Out</button>
                </a>
            </div>
            <!-- Sidebar ends here -->

           
            <!-- Main content area ends here -->
        </div>
    </div>
</body>
</HTML>
