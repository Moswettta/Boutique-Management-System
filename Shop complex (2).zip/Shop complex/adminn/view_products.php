<!DOCTYPE HTML>
<HTML lang="en">
<head>
    <title>Stedmark - View Products</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Internal CSS for styling -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* Header styles */
        header {
            background-color: #007bff;
            color: white;
            padding: 15px 0;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }

        
        .sidebar {
            background-color: #343a40;
            padding: 20px;
            height: 100vh;
            color: white;
            width: 20%;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            margin-bottom: 15px;
        }

        .sidebar button {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #0073e6;
            color: white;
            font-size: 16px;
            cursor: pointer;
            text-align: left;
        }

        .sidebar button:hover {
            background-color: #005bb5;
        }
        /* Content area */
        .content {
            margin-left: 200px;
            padding: 20px;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        img {
            width: 80px;
            height: 60px;
            object-fit: cover;
        }

        /* Button styles */
        .btn {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            text-decoration: none;
        }

        .btn-success {
            background-color: #28a745;
            color: white;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-success:hover, .btn-danger:hover {
            opacity: 0.9;
        }
    </style>

    <script type="text/javascript">
        function sureToApprove(id){
            if(confirm("Are you sure you want to delete this product?")){
                window.location.href = 'delete_prod.php?id=' + id;
            }
        }
    </script>
</head>
<body>

<!-- Main container starts here -->
<header>
    <h1>Welcome to Stedmark - View Products</h1>
</header>

<!-- Sidebar starts here -->
<div class="sidebar">
    <a href="add_women.php">Add Womens' Wear</a>
    <a href="add_kids.php">Add Kids' Wear</a>
    <a href="order.php">Reports</a>
    <a href="feedback.php">Feedback</a>
    <a href="/Fashion/index.php">Log Out</a>
</div>

<!-- Main content area starts here -->
<div class="content">
    <h2>Available Products</h2>
    <table>
        <thead>
            <tr>
                <th>Wear</th>
                <th>Wear Size</th>
                <th>Wear Price</th>
                <th>Quantity</th>
                <th>Image</th>
                <th>Content Management</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include 'config/config.php';
                $sel = "SELECT * FROM product";
                $rs = $conn->query($sel);
                while ($row = $rs->fetch_assoc()) {
            ?>
            <tr class="record">
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['size']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td><?php echo $row['price']; ?></td>
                <td><img src="images/<?php echo $row['image']; ?>" /></td>
                <td>
                    <a href="update.php?id=<?php echo $row['room_id']; ?>" class="btn btn-success btn-sm">
                        Edit
                    </a>
                    <a href="javascript:sureToApprove('<?php echo $row['room_id']; ?>')" class="btn btn-danger btn-sm">
                        Delete
                    </a>
                </td>
            </tr>
            <?php
                }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
