<?php
session_start();

// Database configuration
$servername = "localhost"; // Usually localhost
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "fashion"; // Replace with your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set character set to UTF-8
$conn->set_charset("utf8");

// Calculate total price
$total_price = 0;
if (isset($_SESSION["cart"])) {
    foreach ($_SESSION["cart"] as $item) {
        $total_price += $item['cloth_price'] * $item['cloth_quantity'];
    }
}

// Get user information
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $query = "SELECT name FROM user WHERE id = '$user_id'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);
    $_SESSION['username'] = $user['name']; // Store the name in session
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h1, h3 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f4511e;
            color: white;
        }
        .total {
            font-weight: bold;
            font-size: 18px;
            text-align: right;
        }
        .button {
            background-color: #f4511e;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            display: inline-block;
            border-radius: 5px;
            margin: 5px 0;
        }
        .button:hover {
            background-color: #d1401a;
            transform: translateY(-2px);
        }
        .form-section {
            margin-top: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .navbar {
            display: flex;
            justify-content: center;
            background-color: #333;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .navbar a {
            margin: 0 10px;
            text-decoration: none;
        }
        .navbar button {
            background-color: #f4511e;
            padding: 10px;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .navbar button:hover {
            background-color: #d1401a;
        }
        @media (max-width: 600px) {
            .navbar {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<header>
    <h3>Shopping Cart</h3>
</header>

<nav class="navbar">
    <a href="home.php"><button>Home</button></a>
    <a href="home.php"><button>Shop</button></a>
    <a href="check_out.php"><button>Shopping Cart</button></a>
    <a href="order.php"><button>My Orders</button></a>
    
    <a href="index.php"><button>Log Out</button></a>
</nav>

<div class="container">
    <h1>Your Cart</h1>
    
    <span>Username: <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest'; ?>!</span>

    <?php if (isset($_SESSION["cart"]) && count($_SESSION["cart"]) > 0): ?>
        <form method="post" id="cart-form">
            <table>
                <tr>
                    <th>Select</th>
                    <th>Item Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
                <?php foreach ($_SESSION["cart"] as $index => $item): ?>
                    <tr>
                        <td><input type="checkbox" class="item-checkbox" data-price="<?php echo $item['cloth_price']; ?>" data-quantity="<?php echo $item['cloth_quantity']; ?>" name="selected_items[]" value="<?php echo $index; ?>"></td>
                        <td><?php echo htmlspecialchars($item['cloth_name']); ?></td>
                        <td>Ksh <?php echo number_format($item['cloth_price'], 2); ?></td>
                        <td><?php echo htmlspecialchars($item['cloth_quantity']); ?></td>
                        <td>Ksh <?php echo number_format($item['cloth_price'] * $item['cloth_quantity'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <div>
                <strong>Selected Total: </strong>Ksh <span id="selected-total">0.00</span>
            </div>
            <button type="submit" name="clear_cart" class="button">Clear Cart</button>
        </form>

        <div class="form-section">
            <h4>Checkout</h4>
            <form action="process_payment.php" method="post">
                <input type="hidden" name="total" value="<?php echo htmlspecialchars($total_price); ?>">

                <label for="payment_method">Payment Method:</label>
                <select name="payment_method" id="payment_method" required>
                    <option value="">Select Payment Method</option>
                    <option value="Credit Card">Credit Card</option>
                    <option value="Debit Card">Debit Card</option>
                    <option value="M-Pesa">M-Pesa</option>
                    <option value="PayPal">PayPal</option>
                </select>

                <label for="delivery_address">Delivery Address:</label>
                <input type="text" name="delivery_address" id="delivery_address" required placeholder="Enter your delivery address">

                <!-- Pass selected items to process_payment.php -->
                <input type="hidden" name="selected_items" id="selected_items">

                <button type="submit" class="button" onclick="setSelectedItems()">Proceed to Checkout</button>
            </form>
        </div>

    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</div>

<script>
    const checkboxes = document.querySelectorAll('.item-checkbox');
    const selectedTotal = document.getElementById('selected-total');

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            let total = 0;
            checkboxes.forEach(cb => {
                if (cb.checked) {
                    const price = parseFloat(cb.getAttribute('data-price'));
                    const quantity = parseInt(cb.getAttribute('data-quantity'));
                    total += price * quantity;
                }
            });
            selectedTotal.textContent = total.toFixed(2);
        });
    });

    function setSelectedItems() {
        const selectedItems = [];
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const itemIndex = checkbox.value;
                const itemName = <?php echo json_encode(array_column($_SESSION['cart'], 'cloth_name')); ?>[itemIndex];
                const itemPrice = <?php echo json_encode(array_column($_SESSION['cart'], 'cloth_price')); ?>[itemIndex];
                const itemQuantity = <?php echo json_encode(array_column($_SESSION['cart'], 'cloth_quantity')); ?>[itemIndex];
                selectedItems.push({
                    name: itemName,
                    price: itemPrice,
                    quantity: itemQuantity,
                    total: (itemPrice * itemQuantity).toFixed(2)
                });
            }
        });
        document.getElementById('selected_items').value = JSON.stringify(selectedItems);
    }
</script>

</body>
</html>
