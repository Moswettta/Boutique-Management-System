  <?php          include 'config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rabuor Complex</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
<style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;
  color: #777;
}

.bgimg-1, .bgimg-2, .bgimg-3 {
  position: relative;
  opacity: 0.65;
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

}
.bgimg-1 {
  background-image: url("images/one.jpg");
  min-height: 100%;
}

.bgimg-2 {
  background-image: url("images/two.jpg");
  min-height: 400px;
}

.bgimg-3 {
  background-image: url("images/three.jpg");
  min-height: 400px;
}

.caption {
  position: absolute;
  left: 0;
  top: 50%;
  width: 100%;
  text-align: center;
  color: #000;
}

.caption span.border {
  background-color: #111;
  color: #fff;
  padding: 18px;
  font-size: 25px;
  letter-spacing: 10px;
}

h3 {
  letter-spacing: 5px;
  text-transform: uppercase;
  font: 20px "Lato", sans-serif;
  color: #111;
}
.button {
  border-radius: 2px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 20px;
  width: 120px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: 20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
 <header id="header">
<div class="header">
<div class="container">
  <div class="logo-nav">
    <div class="logo-nav-left">
      <h3><a href="index.php">Rabuor Complex <span>Rabuor</span></a></h3><br>
            </div>
            <div class="log-nav-main">
            <ul class="nav navbar-nav">
    <ul class="nav navbar-right">
        <nav class="navbar navbar-inverse">
      <div class="navbar-header"></div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">

        <ul class="nav navbar-nav" id="menu">
        <a href ="index.php"><button class="button "><span>Home</span></button></a>
        

        <a href ="contact.php"><button class="button "><span>Contact</span></button></a>
        <a href ="login.php"><button class="button "><span>Login</span></button></a>
        <a href ="register.php"><button class="button "><span>Register</span></button></a>
         <a href ="admin_login.php"><button class="button "><span>Admin</span></button></a>


        <li><a href="logout.php"><span class=""></span></a></li>

        </ul>
        <ul class="nav navbar-right">
        </ul></div>
</a>
        </ul>
            </div>
</div>
</div>
</div>
  
</header>


</head>
<body>
 <?php
          
          if(isset($_POST['username'])&& isset($_POST['email'])&& isset($_POST['subject'])&& isset($_POST['feedback'])){
          
          $username=$_POST['username'];
          $email =$_POST['email'];
          $subject=$_POST['subject'];
          $feedback=$_POST['feedback'];
          

          $sql="INSERT INTO feedback VALUES('','$username', '$email', '$subject', '$feedback', NOW())";
          if($conn->query($sql)==TRUE){
          
          echo "<script type = \"text/javascript\">
          alert(\"Your feedback has been submitted successfully..\")
          window.location = (\"contact.php\");</script>";
          
          }else{
          echo "<script> alert('Connection Failed!')</script>";
          }
          }
          
      ?>
      
      <br><br>
<div class="container">
         <div class="panel-group">
            <div class="panel panel-primary">
            <div class="panel-heading"><h3> Feedback Section.</h3></div>
          <div class="panel-body">
          Enter the required details to submit your grievances or compliments.
          <br><br>
        
         </div>
           </div>
  
            </div>

 <div class="jumbotron">
    <div class="container">
    <form role="form" method = "post">
      
              <div class="row">
               
                <div class="col-md-12">
                <div class="Compose-Message">               
                <div class="panel panel-success">
                <div class="panel-heading">
                  Compose New Message 
                </div>
                <div class="panel-body">
                        
                  <label for = "username"><span class="glyphicon glyphicon-user"></span> Enter username : </label>
                  <input type="text" name = "username" class="form-control"  placeholder="Enter username" required><br>
                  
                  <label for = "email"><span class="glyphicon glyphicon-envelope"></span> Enter Email : </label>
                  <input type="text" name = "email" class="form-control"  placeholder="Enter email" required><br>
                  
                  <label for = "subject"><span class="glyphicon glyphicon-tags"></span> Enter Subject :  </label>
                  <input type="text" name = "subject" class="form-control" placeholder="Enter subject" required><br>
                  
                  <label for = "feedback" ><span class="glyphicon glyphicon-edit"></span> Enter Message: </label>
                  <textarea rows="9" name = "feedback" class="form-control" placeholder="Enter message" required></textarea>
                  <hr/>
                  <button type = "submit" name = "bttlogin" class="btn btn-success"><span class="glyphicon glyphicon-envelope"></span> Send Message </a>&nbsp;
              
                </div>
                   
              </div>
              <div class="row">
  <div class="footer">
  <div class="col-md-4 footer-grid">
  <h4><a name="contact"> LOCATE US</a></h4>
  <span class="glyphicon glyphicon-map-marker">PO BOX 12345 -00101<br>Rabuor, Kisumu<br>Kenya</span><br>
  <span class="glyphicon glyphicon-earphone"> 0790113014</span></div>
  <div class="col-md-4 footer-grid">
  <h4>FOLLOWS US</h4>
  <img class="img-responsive" src="images/fb.png" class="img-rounded" width="50" height="30" alt=""/>rabuorcomplex
  <img class="img-responsive" src="images/tw.png" class="img-rounded" width="50" height="30" alt=""/>@rabuorcomplex
  <img class="img-responsive" src="images/google.png" class="img-rounded" width="50" height="30" alt=""/>#rabuorcomplex
  </div>
  <div class="col-md-4 footer-grid">
  <h4>GET IN TOUCH</h4>
  <span class="glyphicon glyphicon-envelope"> rabuorcomplex@example.com</span>
  <img class="img-responsive" src="images/whatsapp.png" class="img-rounded" width="30" height="30" alt=""/>+254 8478478
  </div>
  <div class="col-md-3 footer-grid">
  
  </div>
  </div>
  </div>
  2023 Rabuor Shopping Complex. ALL RIGHTS RESERVED|
</div>
            </div>
          </div> 
          
        </div>
  
    </form>
  </div>
 </div>
 </div>
 <footer>
   dgshd
 </footer>