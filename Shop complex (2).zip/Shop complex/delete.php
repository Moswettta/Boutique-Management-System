<?php
	include 'config/config.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM men WHERE id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo 'Product has Successfully been Deleted';
	?>
		<meta content="4; index.php" http-equiv="refresh" />
	<?php
	}
?>
