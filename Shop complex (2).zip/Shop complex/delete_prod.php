<?php
	include 'connect.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM foods WHERE id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo 'Product has Successfully been Deleted';
	?>
		<meta content="4; index.php" http-equiv="refresh" />
	<?php
	}
?>
