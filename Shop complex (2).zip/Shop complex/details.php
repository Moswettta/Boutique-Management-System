<?php
session_start();
include 'config/config.php'; // Include your database connection
error_reporting(E_ALL); // Enable all error reporting
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Enable detailed MySQLi errors

// Initialize variables for product details
$productDetails = [];
$message = "";

// Check if an ID is passed via the URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure the ID is an integer

    // Fetch product details from the database
    $query = "SELECT * FROM women WHERE id = '$id'"; // Adjust the query according to your database structure
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $productDetails = mysqli_fetch_assoc($result); // Fetch the product details
    } else {
        $message = "Product not found."; // Handle case where product doesn't exist
    }
} else {
    $message = "No product ID provided."; // Handle case where no ID is provided
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #007bff;
            color: white;
            padding: 15px 0;
            text-align: center;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            background-color: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        h2 {
            text-align: center;
            margin: 20px 0;
        }

        .product-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }

        .product-image {
            max-width: 300px;
            margin-right: 20px;
        }

        .product-info {
            flex: 1;
        }

        .button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            text-decoration: none;
        }

        .button:hover {
            background-color: #0056b3;
        }

        .text-danger {
            color: red;
        }

        .message {
            color: red;
            text-align: center;
            margin: 15px 0;
        }
    </style>
</head>
<body>

<div class="header">
    <h3><a href="index.php" style="color: white; text-decoration: none;">Rabour Complex <span>Shop anywhere</span></a></h3>
</div>

<div class="container">
    <h2>Product Details</h2>

    <?php if ($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <?php if (!empty($productDetails)): ?>
        <div class="product-details">
            <div class="product-image">
                <img src="<?php echo $productDetails['image']; ?>" alt="<?php echo $productDetails['cloth_name']; ?>" style="width: 100%;">
            </div>
            <div class="product-info">
                <h3><?php echo $productDetails['cloth_name']; ?></h3>
                <p><strong>Price:</strong> Kshs. <?php echo number_format($productDetails['cloth_price'], 2); ?></p>
                <p><strong>Description:</strong> <?php echo $productDetails['description']; ?></p>
                <p><strong>Available Quantity:</strong> <?php echo $productDetails['available_quantity']; ?></p>
                <a href="add_to_cart.php?id=<?php echo $productDetails['id']; ?>" class="button">Add to Cart</a>
            </div>
        </div>
    <?php else: ?>
        <p>Product details are not available.</p>
    <?php endif; ?>
</div>

</body>
</html>
