<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fashion";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch all data from the 'women' table
$sql = "SELECT * FROM women";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data for each row
    echo '<div class="items-container">';
    while($row = $result->fetch_assoc()) {
        echo '<div class="item">';
        echo '<img src="images/' . $row["image"] . '" alt="' . $row["name"] . '">';
        echo '<h3>' . $row["name"] . '</h3>';
        echo '<p>Size: ' . $row["size"] . '</p>';
        echo '<p>Price: Ksh ' . $row["price"] . '</p>';
        echo '</div>';
    }
    echo '</div>';
} else {
    echo "No items found.";
}

$conn->close();
?>
