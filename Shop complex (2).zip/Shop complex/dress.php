<?php
						session_start();


						include 'config/config.php';
if(isset($_POST['add_to_cart']))
{
	if(isset($_SESSION["cart"]))
	{
	$item_array_id = array_column($_SESSION["cart"],"id");
	if(!in_array($_GET["id"],$item_array_id))
	{
	$count= count($_SESSION["cart"]);
	$item_array = array(
	'cloth_id' 	=>	$_GET["id"],
	'cloth_name'	=>	$_POST["hidden_name"],
	'cloth_price' 	=>	$_POST["hidden_price"],
	'cloth_quantity' => 	$_POST['quantity']
	);
		$_SESSION["cart"][$count] = $item_array;

	}
	else
	{
		echo '<script>alert("Item Already Added")</script>';
				echo '<script>window.location ="prototype.php"</script>';

	}
	}
	else
	{
	$item_array = array(
	'cloth_id' 	=>	$_GET["id"],
	'cloth_name'	=>	$_POST["hidden_name"],
	'cloth_price' 	=>	$_POST["hidden_price"],
	'cloth_quantity' => 	$_POST['quantity']
	);
	$_SESSION["cart"][0] = $item_array;
	}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rabuor Complex</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="side.css" rel="stylesheet" type="text/css"/>
	<link href="css/reservation.css" rel="stylesheet" type="text/css"/>


<style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;
  color: #777;
}

.bgimg-1, .bgimg-2, .bgimg-3 {
  position: relative;
  opacity: 0.65;
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

}
.bgimg-1 {
  background-image: url("images/one.jpg");
  min-height: 100%;
}

.bgimg-2 {
  background-image: url("images/two.jpg");
  min-height: 400px;
}

.bgimg-3 {
  background-image: url("images/three.jpg");
  min-height: 400px;
}

.caption {
  position: absolute;
  left: 0;
  top: 50%;
  width: 100%;
  text-align: center;
  color: #000;
}

.caption span.border {
  background-color: #111;
  color: #fff;
  padding: 18px;
  font-size: 25px;
  letter-spacing: 10px;
}

h3 {
  letter-spacing: 5px;
  text-transform: uppercase;
  font: 20px "Lato", sans-serif;
  color: #111;
}
.button {
  border-radius: 2px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 20px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: 20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>

</head>
<body>
<header id="header">
<div class="header">
<div class="container">
  <div class="logo-nav">
    <div class="logo-nav-left">
      <h3><a href="index.php">Alhassan Shopping  <span>Complex Kitui</span></a></h3><br>
            </div>
            <div class="log-nav-main">
            <ul class="nav navbar-nav">
    <ul class="nav navbar-right">
        <nav class="navbar navbar-inverse">
      <div class="navbar-header"></div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">

        <ul class="nav navbar-nav" id="menu">
        <a href ="home.php"><button class="button "><span>Home</span></button></a>
        

        <a href ="men.php"><button class="button "><span>Men</span></button></a>
        <a href ="women.php"><button class="button "><span>Women</span></button></a>
        <a href ="kids.php"><button class="button "><span>Children</span></button></a>
         <a href ="admin_login.php"><button class="button "><span>Admin</span></button></a>


        <li><a href="logout.php"><span class=""></span></a></li>

        </ul>
        <ul class="nav navbar-right">
        </ul></div>
</a>
        </ul>
            </div>
</div>
</div>
</div>
  
</header>
<div class="container-fluid">
<div id="content_header">

<h3>Women's Wear</h3>
</div>
<div class = "side_content">
    <ul>
			<span id="brand_header"> Categories</span><br>
        <li class="brand">
              <a href="skirts.php">Skirts</a><br>
      <a href="handbags.php">Handbags</a><br>
      <a href="bras.php">Bras</a><br>
      <a href="women_shoes.php">Shoes</a><br>
      <a href="dress.php">Dresses</a><br>
      <a href="women_accessories.php">Accessories</a><br>
      
		  
        </li>
					<span id="brand_header">Price Range</span><br>

        <li class="brand">
          <a href="#">Price Range</a>
        </li>
					<span id="brand_header"> Brands</span><br>

        <li class="brand">
          <a href="#">Brands</a>
        </li>
					<span id="brand_header">Top Rated Products</span><br>

        <li class="brand">
          <a href="#">Top Rated Products</a>
        </li>

    </ul>
  </div>
<div class="main_content">
<div class="wears">
	
	<ul class="wears-list">

<?php
$query = "SELECT * FROM women where name = 'dress'";
						$result = mysqli_query($conn,$query);
						if(mysqli_num_rows($result) >0)
						{
						while($row = $result->fetch_assoc())
						{
						
			?>
				<li>
									<form method="post" action="dress.php?action=add&id=<?php echo $row['id'];?>">

					<a href="?id=<?php echo $rws['id'] ?>">
						<img class="thumb" src="admin/images/<?php echo $row['image'];?>" width="100%" height="10%">
					</a>
					<span class="price"><?php echo 'Kshs.'.$row['price'];?></span>
                    <div class="wears_details">
						<a href="join.php?id=<?php echo $row['id'] ?>"><?php $row['id'];?> </a>
						<h4><span class="property_size"><?php echo $row['name'];?></span></h4>
						<h4><span class="property_size"><?php echo $row['size'];?></span></h4>
						<input type="text" name="quantity" class="form-control" value="1"/>
						<input type="hidden" name="hidden_name" value="<?php echo $row['name'];?>"/>
						<input type="hidden" name="hidden_price" value="<?php echo $row['price'];?>"/><br>
						<input type="submit" name="add_to_cart" class="button" value="Add to cart"/>
  
					</form>
				</li>
				
			<?php
				}}
			?>
    
</ul>
</div>
</div>
</div>
