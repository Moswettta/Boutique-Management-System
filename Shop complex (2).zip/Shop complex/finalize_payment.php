<?php
session_start();
include 'config/config.php'; // Include your database connection file

// Check if the user has reached this page via the payment confirmation form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from the form
    $total_price = isset($_POST['total']) ? $_POST['total'] : 0;
    $payment_method = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
    $delivery_address = isset($_POST['delivery_address']) ? $_POST['delivery_address'] : '';

    // Validate input data
    if (empty($payment_method) || empty($delivery_address)) {
        echo "Please provide a payment method and delivery address.";
        exit();
    }

    // Retrieve user ID from session (assuming it's stored during login)
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;

    // Prepare the SQL statement
    $query = "INSERT INTO payments (user_id, total_amount, payment_method, delivery_address, payment_date) VALUES (?, ?, ?, ?, NOW())";

    // Prepare the statement
    $stmt = $conn->prepare($query);
    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("isss", $user_id, $total_price, $payment_method, $delivery_address);

        // Execute the statement
        if ($stmt->execute()) {
            echo "<script>alert('Payment processed successfully!');</script>";
            // Optionally, you can redirect to a confirmation page or receipt page
            header("Location: receipt.php");
            exit();
        } else {
            // Handle error
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

} else {
    // If the page is accessed without a POST request
    echo "Invalid request.";
    exit();
}

// Close the database connection
$conn->close();
?>
