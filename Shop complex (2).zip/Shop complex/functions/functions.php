<?php
include 'config/config.php';
function cart()
{
if(isset($_GET['cart']))
{
$product_id = $_GET[' cart'];
$check_pro ="select * from cart where p_id='$product_id'";

$run_check = mysqli_query($conn,$check_pro);

if(mysqli_num_rows($run_check)>0)
{
echo "";
}
else 
{
$insert_pro = "insert into cart (p_id) values ('$product_id')";
$run_pro = mysqli_query($conn,$insert_pro);
echo "<script>window.open(men.php)</script>";
}
}
}