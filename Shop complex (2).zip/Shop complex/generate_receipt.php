<?php
// Database connection
$servername = "localhost"; // Adjust this if needed
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "fashion"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if order_id is set via GET or POST
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : (isset($_POST['order_id']) ? $_POST['order_id'] : null);

if ($order_id) {
    // Fetch the order details
    $query = "SELECT * FROM orders WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the order details
        $order = $result->fetch_assoc();

        // Fetch the order items
        $items_query = "SELECT item_name, quantity, price FROM order_items WHERE order_id = ?";
        $items_stmt = $conn->prepare($items_query);
        $items_stmt->bind_param("i", $order_id);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();

        echo "<html>
                <head>
                    <title>Receipt for Order #{$order['id']}</title>
                    <style>
                        body {
                            font-family: 'Helvetica', Arial, sans-serif;
                            background-color: #f4f4f4;
                            margin: 0;
                            padding: 20px;
                        }
                        .receipt-container {
                            background-color: #fff;
                            padding: 30px;
                            border-radius: 10px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                            max-width: 800px;
                            margin: auto;
                        }
                        .company-info {
                            text-align: center;
                            margin-bottom: 40px;
                        }
                        .company-info h1 {
                            font-size: 24px;
                            text-transform: uppercase;
                            margin-bottom: 0;
                        }
                        .company-info p {
                            font-size: 14px;
                            color: #777;
                            margin: 5px 0;
                        }
                        .details {
                            margin-bottom: 30px;
                        }
                        .details div {
                            margin: 10px 0;
                            font-size: 16px;
                        }
                        .items {
                            width: 100%;
                            border-collapse: collapse;
                            margin-top: 20px;
                        }
                        .items th, .items td {
                            border: 1px solid #ddd;
                            padding: 12px;
                            text-align: left;
                        }
                        .items th {
                            background-color: #f7f7f7;
                            font-size: 16px;
                        }
                        .total {
                            margin-top: 30px;
                            font-size: 18px;
                            text-align: right;
                            font-weight: bold;
                        }
                        .total .amount {
                            color: #000;
                        }
                        .receipt-footer {
                            margin-top: 50px;
                            text-align: center;
                            color: #888;
                            font-size: 14px;
                        }
                        .print-button {
                            display: inline-block;
                            margin: 30px auto;
                            padding: 10px 20px;
                            background-color: #007BFF;
                            color: #fff;
                            border: none;
                            border-radius: 5px;
                            font-size: 16px;
                            cursor: pointer;
                        }
                        .print-button:hover {
                            background-color: #0056b3;
                        }
                    </style>
                    <script>function printReceipt() { window.print(); }</script>
                </head>
                <body>
                    <div class='receipt-container'>
                        <div class='company-info'>
                            <h1>Fashion Hub</h1>
                            <p>123 Main Street, Nairobi</p>
                            <p>Phone: +254 712 345 678 | Email: info@fashionhub.com</p>
                            <p>Receipt Date: " . date("F d, Y") . "</p>
                        </div>

                        <div class='details'>
                            <div><strong>Order ID:</strong> {$order['id']}</div>
                            <div><strong>Username:</strong> {$order['username']}</div>
                            <div><strong>Delivery Address:</strong> {$order['delivery_address']}</div>
                            <div><strong>Payment Method:</strong> {$order['payment_method']}</div>
                            <div><strong>Status:</strong> {$order['status']}</div>
                            <div><strong>Order Date:</strong> {$order['order_date']}</div>
                        </div>

                        <h2>Items Ordered</h2>
                        <table class='items'>
                            <thead>
                                <tr>
                                    <th>Item Name</th>
                                    <th>Quantity</th>
                                    <th>Price (Ksh)</th>
                                    <th>Subtotal (Ksh)</th>
                                </tr>
                            </thead>
                            <tbody>";

        // Loop through the items and display them
        $total = 0;
        while ($item = $items_result->fetch_assoc()) {
            $subtotal = $item['quantity'] * $item['price'];
            $total += $subtotal;
            echo "<tr>
                    <td>{$item['item_name']}</td>
                    <td>{$item['quantity']}</td>
                    <td>{$item['price']}</td>
                    <td>{$subtotal}</td>
                  </tr>";
        }

        echo "      </tbody>
                        </table>
                        <div class='total'>
                            <strong>Total Price: </strong><span class='amount'>Ksh {$total}</span>
                        </div>

                        <button class='print-button' onclick='printReceipt()'>Print Receipt</button>

                        <div class='receipt-footer'>
                            Thank you for shopping with Fashion Hub!<br>
                            Visit again soon.
                        </div>
                    </div>
                </body>
              </html>";

        $items_stmt->close();
    } else {
        echo "<script>alert('No order found with this ID.'); window.location.href = 'your_current_page.php';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Invalid request.'); window.location.href = 'your_current_page.php';</script>";
}

$conn->close();
?>
