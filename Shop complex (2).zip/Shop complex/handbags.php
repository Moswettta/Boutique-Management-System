<?php
session_start();
include 'config/config.php';

if (isset($_POST['add_to_cart'])) {
    if (isset($_SESSION["cart"])) {
        $item_array_id = array_column($_SESSION["cart"], "id");
        if (!in_array($_GET["id"], $item_array_id)) {
            $count = count($_SESSION["cart"]);
            $item_array = array(
                'cloth_id' => $_GET["id"],
                'cloth_name' => $_POST["hidden_name"],
                'cloth_price' => $_POST["hidden_price"],
                'cloth_quantity' => $_POST['quantity']
            );
            $_SESSION["cart"][$count] = $item_array;
        } else {
            echo '<script>alert("Item Already Added")</script>';
            echo '<script>window.location ="prototype.php"</script>';
        }
    } else {
        $item_array = array(
            'cloth_id' => $_GET["id"],
            'cloth_name' => $_POST["hidden_name"],
            'cloth_price' => $_POST["hidden_price"],
            'cloth_quantity' => $_POST['quantity']
        );
        $_SESSION["cart"][0] = $item_array;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rabuor Complex</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
        }
        .header h3 a {
            color: white;
            text-decoration: none;
            padding: 0 20px;
        }
        .header span {
            font-size: 14px;
            color: #bbb;
        }
        .nav {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
        }
        .nav li {
            padding: 0 15px;
        }
        .nav li a {
            color: white;
            text-decoration: none;
        }
        .container {
            padding: 20px;
        }
        .side_content {
            width: 20%;
            float: left;
            background-color: #fff;
            padding: 15px;
            margin-right: 2%;
        }
        .side_content ul {
            list-style: none;
            padding: 0;
        }
        .side_content ul li {
            margin-bottom: 10px;
        }
        .side_content a {
            text-decoration: none;
            color: #333;
        }
        .main_content {
            width: 75%;
            float: left;
        }
        .wears-list {
            display: flex;
            flex-wrap: wrap;
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .wears-list li {
            width: 30%;
            margin: 1%;
            padding: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
        }
        .thumb {
            width: 100%;
            height: auto;
        }
        .price {
            color: #e74c3c;
            font-size: 18px;
            font-weight: bold;
        }
        .wears_details {
            margin-top: 10px;
        }
        .wears_details h4 {
            margin: 5px 0;
        }
        .form-control {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            box-sizing: border-box;
        }
        .button {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
        }
        .button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<div class="header">
    <div class="container">
        <div class="logo-nav-left">
            <h3><a href="index.php">RABUOR COMPLEX<span>Shop anywhere</span></a></h3>
        </div>
        <ul class="nav">
            <li><a href="home.php">Home</a></li>
            <li><a href="women.php">Women</a></li>
            <li><a href="men.php">Men</a></li>
            <li><a href="kids.php">Children</a></li>
        </ul>
    </div>
</div>

<a href="check_out.php"><img class="responsive" src="images/viewcart.png" width="18%"></a>

<div class="container">
    <h3>Women's Wear</h3>
    <div class="side_content">
        <ul>
            <span id="brand_header">Categories</span><br>
            <li class="brand"><a href="skirts.php">Skirts</a></li>
            <li class="brand"><a href="handbags.php">Handbags</a></li>
            <li class="brand"><a href="bras.php">Bras</a></li>
            <li class="brand"><a href="women_shoes.php">Shoes</a></li>
            <li class="brand"><a href="dress.php">Dresses</a></li>
            <li class="brand"><a href="women_accessories.php">Accessories</a></li>
        </ul>
    </div>

    <div class="main_content">
        <ul class="wears-list">
            <?php
            $query = "SELECT * FROM women where name = 'handbag'";
            $result = mysqli_query($conn, $query);
            if (mysqli_num_rows($result) > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <li>
                        <form method="post" action="handbags.php?action=add&id=<?php echo $row['id']; ?>">
                            <a href="?id=<?php echo $rws['id'] ?>">
                                <img class="thumb" src="admin/images/<?php echo $row['image']; ?>">
                            </a>
                            <span class="price"><?php echo 'Kshs.'.$row['price']; ?></span>
                            <div class="wears_details">
                                <h4><?php echo $row['name']; ?></h4>
                                <h4>Size: <?php echo $row['size']; ?></h4>
                                <input type="text" name="quantity" class="form-control" value="1">
                                <input type="hidden" name="hidden_name" value="<?php echo $row['name']; ?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $row['price']; ?>"><br>
                                <input type="submit" name="add_to_cart" class="button" value="Add to cart">
                            </div>
                        </form>
                    </li>
                    <?php
                }
            }
            ?>
        </ul>
    </div>
</div>

</body>
</html>
