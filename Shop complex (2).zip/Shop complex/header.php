<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>RABUOR COMPLEX</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="reservation.css"rel="stylesheet" type="text/css"/>

</head>
<header>
    <div class="jumbotron">
        <div class="container-fluid">
            <div class="main-head">
                <span>S</span>Rabuor complex<span>L</span>
<?php include 'connect.php'?>
            <?php include 'function.php'?>
            <?php include 'title_bar.php'?>
            </div>


            
        </div>
</header>