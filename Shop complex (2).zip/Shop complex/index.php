
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>RABUOR COMPLEX</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
<style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;
  color: #777;
}

.bgimg-1, .bgimg-2, .bgimg-3 {
  position: relative;
  opacity: 0.65;
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

}
.bgimg-1 {
  background-image: url("images/one.jpg");
  min-height: 100%;
}

.bgimg-2 {
  background-image: url("images/two.jpg");
  min-height: 400px;
}

.bgimg-3 {
  background-image: url("images/three.jpg");
  min-height: 400px;
}

.caption {
  position: absolute;
  left: 0;
  top: 50%;
  width: 100%;
  text-align: center;
  color: #000;
}

.caption span.border {
  background-color: #111;
  color: #fff;
  padding: 18px;
  font-size: 25px;
  letter-spacing: 10px;
}

h3 {
  letter-spacing: 5px;
  text-transform: uppercase;
  font: 20px "Lato", sans-serif;
  color: #111;
}
.button {
  border-radius: 2px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 20px;
  width: 120px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: 20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
 <header id="header">
<div class="header">
<div class="container">
  <div class="logo-nav">
    <div class="logo-nav-left">
      <h3><a href="index.php">RABUOR COMPLEX  <span>RABUOR</span></a></h3><br>
            </div>
            <div class="log-nav-main">
            <ul class="nav navbar-nav">
    <ul class="nav navbar-right">
        <nav class="navbar navbar-inverse">
      <div class="navbar-header"></div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">

        <ul class="nav navbar-nav" id="menu">
        <a href ="index.php"><button class="button "><span>Home</span></button></a>
        

        <a href ="contact.php"><button class="button "><span>Contact</span></button></a>
        <a href ="login.php"><button class="button "><span>Login</span></button></a>
        <a href ="register.php"><button class="button "><span>Register</span></button></a>
         <a href ="admin_login.php"><button class="button "><span>Admin</span></button></a>


        <li><a href="logout.php"><span class=""></span></a></li>

        </ul>
        <ul class="nav navbar-right">
        </ul></div>
</a>
        </ul>
            </div>
</div>
</div>
</div>
  
</header>

</head>
<body>

<div class="bgimg-1">
  <div class="caption">
    <span class="border">RABUOR</span>
  </div>
</div>

<div style="color: #777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
  <h3 style="text-align:center;">Our Mission:</h3>
  <p>To provide benchmark accommodation and distinctive conference facilities that delight our customers,
    and deliver on-going meaningful resources to the humanitarian activities of the Kenya Red Cross Society.</div>
</p>
</div>

<div class="bgimg-2">
  <div class="caption">
    <span class="border" style="background-color:transparent;font-size:25px;color: #f7f7f7;">Get Ultimate Comfort</span>
  </div>
</div>

<div style="position:relative;">
  <div style="color:#ddd;background-color:#282E34;text-align:center;padding:50px 80px;text-align: justify;">
<p>To provide benchmark accommodation and distinctive conference facilities that delight our customers,
                    and deliver on-going meaningful resources to the humanitarian activities of the hotel.</p>  </div>
</div>

<div class="bgimg-3">
  <div class="caption">
    <span class="border" style="background-color:transparent;font-size:25px;color: #f7f7f7;"></span>
  </div>
</div>

<div style="position:relative;">
  <div style="color:#ddd;background-color:#282E34;text-align:center;padding:50px 80px;text-align: justify;">
Offer a sharing platform where clients and the hotel can interact.</p>  </div>
</div>

<div class="bgimg-1">
  <div class="caption">
    <span class="border">High Quality Service</span>
  </div>
</div>
<div class="modal fade" id ="myModal2" role="dialog">
      <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">SIGN UP</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form action="index.php" method="POST">
          <form role="form">
          <div class="form-group">
          </div>
        
    <tr>
              <td><label for="user_name">User Name:</label></td>
              <td><input type="text" class="form-control" name="user_name" required></td>
            </tr>
            <tr>
              <td><label for="user_name">Email:</label></td>
              <td><input type="text" class="form-control" name="email" required></td>
            </tr>
<tr>
              <td><label for="password">Password:</label></td>
              <td><input type="password" class="form-control" name="password" required></td>
            </tr>
            <tr>
              <td><label for="password">Confirm Password:</label></td>
              <td><input type="password" class="form-control" name="confirm" required></td>
            </tr>
<br/>
<input type='submit' class="btn btn-success"name='submit' value='Login'></span></input>
</form>

          </form>
          </form>
        </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id ="myModal" role="dialog">
      <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">LOG IN</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form action="index.php" method="POST">
          <form role="form">
          <div class="form-group">
          </div>
        
    <tr>
              <td><label for="user_name">User Name:</label></td>
              <td><input type="text" class="form-control" name="user_name" required></td>
            </tr>
            
<tr>
              <td><label for="password">Password:</label></td>
              <td><input type="password" class="form-control" name="password" required></td>
            </tr>
            
<br/>
<input type='submit' class="btn btn-success"name='submit' value='Login'></span></input>
</form>

          </form>
          </form>
        </div>
        </div>
      </div>
    </div>
  
    
</body>
</html>