<?php
// Include your functions and configuration files
include 'function.php';
include 'config/config.php';

// Start the session only if it hasn't been started
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Start the session
}

// Handle form submission
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $password = $_POST['password'];

    if (empty($name) || empty($password)) {
        echo "<p>Fields Empty!</p>";
    } else {
        // Query to check login
        $check_login = "SELECT id FROM user WHERE name = '$name' AND password = '$password'";
        $run_user = mysqli_query($conn, $check_login);
        $check_user = mysqli_num_rows($run_user);

        if ($check_user > 0) {
            // Fetch the user ID (if needed)
            $row = mysqli_fetch_assoc($run_user);
            $id = $row['id'];

            // Store user ID and name in session
            $_SESSION['user_id'] = $id;
            $_SESSION['client_name'] = $name; // Store the name in session

            echo "<script>
            alert('Login Successful');
            window.location = ('home.php')
            </script>";
        } else {
            echo "<script>alert('Connection Failed!, Wrong Username or Password')</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>RABUOR COMPLEX</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font: 400 15px/1.8 "Lato", sans-serif;
            color: #777;
        }

        .bgimg-1, .bgimg-2, .bgimg-3 {
            position: relative;
            opacity: 0.65;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .bgimg-1 {
            background-image: url("images/one.jpg");
            min-height: 35%;
        }

        .bgimg-2 {
            background-image: url("images/two.jpg");
            min-height: 15%;
        }

        .bgimg-3 {
            background-image: url("images/three.jpg");
            min-height: 400px;
        }

        .caption {
            position: absolute;
            left: 0;
            top: 10%;
            width: 100%;
            text-align: center;
            color: #000;
        }

        .caption span.border {
            background-color: #111;
            color: #fff;
            padding: 18px;
            font-size: 25px;
            letter-spacing: 10px;
        }

        h3 {
            letter-spacing: 5px;
            text-transform: uppercase;
            font: 20px "Lato", sans-serif;
            color: #111;
        }

        .button {
            border-radius: 2px;
            background-color: #f4511e;
            border: none;
            color: #FFFFFF;
            text-align: center;
            font-size: 15px;
            padding: 20px;
            width: 120px;
            transition: all 0.5s;
            cursor: pointer;
            margin: 5px;
        }

        .button span {
            cursor: pointer;
            display: inline-block;
            position: relative;
            transition: 0.5s;
        }

        .button span:after {
            content: '»';
            position: absolute;
            opacity: 0;
            top: 0;
            right: 20px;
            transition: 0.5s;
        }

        .button:hover span {
            padding-right: 25px;
        }

        .button:hover span:after {
            opacity: 1;
            right: 0;
        }
    </style>
</head>
<body>
    <header id="header">
        <div class="header">
            <div class="container">
                <div class="logo-nav">
                    <div class="logo-nav-left">
                        <h3><a href="index.php">RABUOR COMPLEX<span>RABUOR</span></a></h3><br>
                    </div>
                    <div class="log-nav-main">
                        <ul class="nav navbar-nav">
                            <ul class="nav navbar-right">
                                <nav class="navbar navbar-inverse">
                                    <div class="navbar-header"></div>
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavbar">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                    <div class="collapse navbar-collapse" id="mainNavbar">
                                        <ul class="nav navbar-nav" id="menu">
                                            <a href="index.php"><button class="button"><span>Home</span></button></a>
                                            <a href="index.php"><button class="button"><span>Contact</span></button></a>
                                            <a href="login.php"><button class="button"><span>Login</span></button></a>
                                            <a href="register.php"><button class="button"><span>Register</span></button></a>
                                            <li><a href="logout.php"><span class=""></span></a></li>
                                        </ul>
                                        <ul class="nav navbar-right"></ul>
                                    </div>
                                </nav>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="bgimg-1">
        <div class="caption">
            <span class="border">Client/Log In</span>
        </div>
    </div>

    <div style="color: #777; background-color:white; text-align:center; padding:50px 80px; text-align: justify;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header"></div>
                <div class="modal-body">
                    <div id="theform">
                        <h3>Login Here: </h3>
                        <form method="post">
                            <label for="name">Name:</label>
                            <input type="text" class="form-control" name="name" required>
                            <label for="password">Password:</label>
                            <input type="password" class="form-control" name="password" maxlength="6" required>
                            <br/>
                            <input type='submit' class="btn btn-success" name='submit' value='Login'>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bgimg-2">
        <div class="caption">
            <span class="border" style="background-color:transparent;font-size:25px;color: #f7f7f7;">Get Ultimate Comfort</span>
        </div>
    </div>
</body>
</html>
