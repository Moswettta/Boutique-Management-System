<?php
session_start();

// Database configuration
$servername = "localhost"; // Usually localhost
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "fashion"; // Replace with your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set character set to UTF-8
$conn->set_charset("utf8");

// Fetch the user's orders
$username = $_SESSION['username'] ?? 'Guest'; // Get username from session or set to 'Guest'

// Prepare statement to fetch orders
$query = "SELECT o.id, o.delivery_address, o.payment_method, o.total_price, o.status, o.order_date 
          FROM orders o WHERE o.username = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Error preparing order statement: " . $conn->error);
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Delete order logic
if (isset($_POST['delete_order'])) {
    $order_id = $_POST['order_id'];
    $delete_query = "DELETE FROM orders WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("i", $order_id);

    if ($delete_stmt->execute()) {
        echo "<script>alert('Order deleted successfully.'); window.location.href = 'order.php';</script>";
    } else {
        echo "<script>alert('Error deleting order: " . $conn->error . "');</script>";
    }

    $delete_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .header-nav {
            text-align: center;
            margin-bottom: 20px;
        }
        .header-nav a {
            text-decoration: none;
            margin-right: 10px;
        }
        .header-nav button {
            padding: 10px 20px;
            background-color: #f4511e;
            border: none;
            color: white;
            cursor: pointer;
            margin-right: 10px;
        }
        .header-nav button:hover {
            background-color: #d1401a;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4511e;
            color: white;
        }
        .button {
            background-color: #f4511e;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
            display: inline-block;
            margin-top: 20px;
        }
        .button:hover {
            background-color: #d1401a;
        }
    </style>
</head>
<body>

<!-- Header Section -->
<div class="header-nav">
    <a href="home.php"><button>Home</button></a>
    <a href="women.php"><button>Shop</button></a>
    <a href="check_out.php"><button>Shopping Cart</button></a>
    <a href="order.php"><button>My Orders</button></a>
    <a href="index.php"><button>Log Out</button></a>
</div>

<div class="container">
    <h1>Your Orders</h1>
    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Order ID</th>
                <th>Delivery Address</th>
                <th>Payment Method</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>Order Date</th>
                <th>Actions</th>
            </tr>
            <?php while ($order = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $order['id']; ?></td>
                    <td><?php echo htmlspecialchars($order['delivery_address']); ?></td>
                    <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                    <td>Ksh <?php echo number_format($order['total_price'], 2); ?></td>
                    <td><?php echo htmlspecialchars($order['status']); ?></td>
                    <td><?php echo htmlspecialchars(date('Y-m-d H:i:s', strtotime($order['order_date']))); ?></td>
                    <td>
                        <form method="post" action="">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <button type="submit" name="delete_order" class="button">Delete</button>
                        </form>
                        <?php if ($order['status'] === 'Approved'): ?>
                            <a href="generate_receipt.php?order_id=<?php echo $order['id']; ?>" class="button">Generate Receipt</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php
                // Fetch order items for this order
                $order_id = $order['id'];
                $item_query = "SELECT item_name, price, quantity, total FROM order_items WHERE order_id = ?";
                $item_stmt = $conn->prepare($item_query);

                if (!$item_stmt) {
                    die("Error preparing item statement: " . $conn->error);
                }

                $item_stmt->bind_param("i", $order_id);
                $item_stmt->execute();
                $item_result = $item_stmt->get_result();

                if ($item_result->num_rows > 0): ?>
                    <tr>
                        <td colspan="7">
                            <table>
                                <tr>
                                    <th>Item Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                </tr>
                                <?php while ($item = $item_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                        <td>Ksh <?php echo number_format($item['price'], 2); ?></td>
                                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                        <td>Ksh <?php echo number_format($item['total'], 2); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </table>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>You have no orders yet.</p>
    <?php endif; ?>
    <a href="home.php" class="button">Back to Home</a>
</div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
