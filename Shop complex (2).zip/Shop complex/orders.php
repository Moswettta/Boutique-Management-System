<?php
session_start();
include 'config/config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch orders from the database
$query = "SELECT * FROM orders"; // Fetching all orders
$result = mysqli_query($conn, $query);

if (!$result) {
    die('Query Failed: ' . mysqli_error($conn));
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = "DELETE FROM orders WHERE order_id = '$delete_id'";
    mysqli_query($conn, $delete_query);
    header('Location: orders.php'); // Refresh the page after deletion
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Orders</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body {
            padding: 20px;
        }
        table {
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Your Orders</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Buyer Name</th>
                <th>Product Ordered</th>
                <th>Amount Paid</th>
                <th>Status</th>
                <th>Delivery Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($order['client_name'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($order['order_items'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($order['total_price'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($order['payment_method'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($order['delivery_address'] ?? 'N/A'); ?></td>
                    <td>
                        <a href="orders.php?delete_id=<?php echo $order['order_id']; ?>" onclick="return confirm('Are you sure you want to delete this order?');" class="btn btn-danger btn-sm">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="js/jquery-1.12.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
