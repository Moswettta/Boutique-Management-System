<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>RABUOR COMPLEX</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
    <link href="css/index.css" rel="stylesheet" type="text/css"/>
    <link href="css/school.css" rel="stylesheet" type="text/css"/>
    <link href="css/style2.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="css/style1.css" rel="stylesheet" type="text/css" media="all" /> 
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font: 400 15px/1.8 "Lato", sans-serif;
            color: #777;
        }

        .bgimg-1, .bgimg-2, .bgimg-3 {
            position: relative;
            opacity: 0.65;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        .bgimg-1 {
            background-image: url("images/one.jpg");
            min-height: 100%;
        }
        .bgimg-2 {
            background-image: url("images/two.jpg");
            min-height: 400px;
        }
        .bgimg-3 {
            background-image: url("images/three.jpg");
            min-height: 400px;
        }

        .caption {
            position: absolute;
            left: 0;
            top: 50%;
            width: 100%;
            text-align: center;
            color: #000;
        }

        .caption span.border {
            background-color: #111;
            color: #fff;
            padding: 18px;
            font-size: 25px;
            letter-spacing: 10px;
        }

        h3 {
            letter-spacing: 5px;
            text-transform: uppercase;
            font: 20px "Lato", sans-serif;
            color: #111;
        }
        .button {
            border-radius: 2px;
            background-color: #f4511e;
            border: none;
            color: #FFFFFF;
            text-align: center;
            font-size: 15px;
            padding: 20px;
            width: 120px;
            transition: all 0.5s;
            cursor: pointer;
            margin: 5px;
        }

        .button span {
            cursor: pointer;
            display: inline-block;
            position: relative;
            transition: 0.5s;
        }

        .button span:after {
            content: '»';
            position: absolute;
            opacity: 0;
            top: 0;
            right: 20px;
            transition: 0.5s;
        }

        .button:hover span {
            padding-right: 25px;
        }

        .button:hover span:after {
            opacity: 1;
            right: 0;
        }
    </style>
</head>
<body>
<header id="header">
    <div class="header">
        <div class="container">
            <div class="logo-nav">
                <div class="logo-nav-left">
                    <h3><a href="index.php">RABUOR COMPLEX <span>RABUOR</span></a></h3><br>
                </div>
                <div class="log-nav-main">
                    <ul class="nav navbar-nav">
                        <ul class="nav navbar-right">
                            <nav class="navbar navbar-inverse">
                                <div class="navbar-header"></div>
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavbar">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="mainNavbar">
                                    <ul class="nav navbar-nav" id="menu">
                                        <a href ="men.php"><button class="button"><span>Men</span></button></a>
                                        <a href ="women.php"><button class="button"><span>Women</span></button></a>
                                        <a href ="kids.php"><button class="button"><span>Kids</span></button></a>
                                        <li><a href="logout.php"><span class=""></span></a></li>
                                    </ul>
                                    <ul class="nav navbar-right"></ul>
                                </div>
                            </nav>
                        </ul>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>

<div class="col-md-6">
    <h3 style="text-decoration: underline">Make Payments Here</h3>
    <h5>TILL Number: 13579</h5>
    <h6>Business Number: ID Number Registered with.</h6>
    <form method="post">
        <table>
            <tr>
                <td><label for="mpesa">MPESA Transaction Code:</label></td>
                <td><input type="text" class="form-control" name="mpesa" required></td>
            </tr>
            <tr>
                <td><label for="id_no">National ID Number:</label></td>
                <td><input type="text" class="form-control" name="id_no" required></td>
            </tr>
            <tr>
                <td><label for="estate">Enter Your Estate:</label></td>
                <td>
                    <select class="form-control" name="estate">
                        <option>Bondeni</option>
                        <option>California</option>
                        <option>Jicca</option>
                        <option>Site</option>
                        <option>Kalundu</option>
                        <option>Mjini</option>
                        <option>Mosquito</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align:right"><input type="submit" class="btn btn-success" name="send" value="Pay Here"></td>
            </tr>
        </table>
    </form>
</div>

<div class="col-md-6">
    <a href="receipt.php"><td colspan="2" style="text-align:right"><input type="submit" class="btn btn-success" value="Cash On Delivery"></td></a>
</div>

<?php 
session_start();
if(isset($_POST['send'])){
    include 'config/config.php';
    $mpesa = $_POST['mpesa'];
    $id_no = $_POST['id_no'];
    $estate = $_POST['estate'];

    // Insert payment into the database
    $qry = "INSERT INTO payments (transaction, id_no, estate, time) VALUES ('$mpesa', '$id_no', '$estate', NOW())";
    $result = $conn->query($qry);
    
    // Check if the insertion was successful
    if ($result == TRUE) {
        // Clear the shopping cart
        if (isset($_SESSION["cart"])) {
            unset($_SESSION["cart"]); // Remove all items from the cart
        }

        echo "<script type='text/javascript'>
            alert('Payment Done Successfully');
            window.location = 'receipt.php';
        </script>";
    } else {
        echo "Payment failed. Please try again.";
    }
}
?>

</body>
</html>
