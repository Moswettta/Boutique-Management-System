<?php
session_start();
include 'config/config.php'; // Assuming this file contains the DB connection

// Fetch the client's name from session
$client_name = $_SESSION['client_name'];

// Assuming you have the session_id stored in the session
$session_id = session_id();
$selected_total = 0; // Initialize total to 0

// Fetch cart items from session
$cart_items = [];
$product_details = '';

if (isset($_SESSION["cart"])) {
    foreach ($_SESSION["cart"] as $item) {
        $cart_items[] = $item;
        $product_details .= $item['cloth_name'] . ' (Quantity: ' . $item['cloth_quantity'] . '), ';
        // Calculate total price
        $selected_total += $item['cloth_quantity'] * $item['cloth_price'];
    }
    $product_details = rtrim($product_details, ', '); // Remove trailing comma
}

// Process the payment form when submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $delivery_address = mysqli_real_escape_string($conn, $_POST['delivery_address']);
    $payment_option = mysqli_real_escape_string($conn, $_POST['payment_option']);
    $payment_details = mysqli_real_escape_string($conn, $_POST['payment_details']);

    // Insert the payment details into the orders table
    $query = "INSERT INTO orders (client_name, delivery_address, product_details, payment_option, payment_details, total_amount) 
              VALUES ('$client_name', '$delivery_address', '$product_details', '$payment_option', '$payment_details', '$selected_total')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Payment Successful!'); window.location='confirmation.php';</script>";
    } else {
        echo "<script>alert('Payment Failed. Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Payment Information</h2>

        <form method="post">
            <div class="form-group">
                <label>Client Name:</label>
                <input type="text" class="form-control" name="client_name" value="<?php echo htmlspecialchars($client_name); ?>" readonly>
            </div>

            <div class="form-group">
                <label>Delivery Address:</label>
                <input type="text" class="form-control" name="delivery_address" required>
            </div>

            <div class="form-group">
                <label>Products:</label>
                <textarea class="form-control" rows="3" readonly><?php echo htmlspecialchars($product_details); ?></textarea>
            </div>

            <div class="form-group">
                <label>Total Amount: </label>
                <input type="text" class="form-control" name="total_amount" value="<?php echo number_format($selected_total, 2); ?>" readonly>
            </div>

            <div class="form-group">
                <label>Payment Option:</label>
                <select class="form-control" name="payment_option" required>
                    <option value="mpesa">M-Pesa</option>
                    <option value="debit">Debit Card</option>
                    <option value="credit">Credit Card</option>
                </select>
            </div>

            <div class="form-group">
                <label>Payment Details (e.g., Phone Number or Card Number):</label>
                <input type="text" class="form-control" name="payment_details" required>
            </div>

            <button type="submit" class="btn btn-primary">Submit Payment</button>
        </form>
    </div>
</body>
</html>
