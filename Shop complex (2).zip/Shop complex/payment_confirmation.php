<?php
session_start();
error_reporting(0);

// Include config
include 'config/config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve payment method and address from POST data
    $payment_method = $_POST['payment_method'];
    $address = $_POST['address'];
    $total_amount = $_POST['total']; // Assuming this is passed from the payment options page

    // Here you would process the payment according to the selected method
    // For demonstration purposes, we're just simulating a payment process

    // Process the payment (This is a placeholder for actual payment processing)
    if ($payment_method == "mpesa") {
        // Simulate M-Pesa payment process
        // You would typically integrate with M-Pesa API here
        $payment_status = "Payment successful via M-Pesa.";
    } elseif ($payment_method == "debit_card") {
        // Simulate debit card payment process
        // You would typically integrate with a payment gateway here
        $payment_status = "Payment successful via Debit Card.";
    } elseif ($payment_method == "credit_card") {
        // Simulate credit card payment process
        // You would typically integrate with a payment gateway here
        $payment_status = "Payment successful via Credit Card.";
    } else {
        $payment_status = "Payment method not recognized.";
    }

    // Clear the cart after payment
    unset($_SESSION["cart"]);

    // Display confirmation message
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment Confirmation</title>
        <link rel="stylesheet" href="styles.css">
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 20px;
            }
            h2 {
                color: green;
            }
            p {
                font-size: 16px;
            }
            .button {
                padding: 10px 20px;
                background-color: blue;
                color: white;
                border: none;
                cursor: pointer;
                text-decoration: none;
            }
            .button:hover {
                background-color: darkblue;
            }
        </style>
    </head>
    <body>

    <h2>Payment Confirmation</h2>
    <p><?php echo $payment_status; ?></p>
    <p>Your order has been placed successfully.</p>
    <p>Your delivery address: <?php echo htmlspecialchars($address); ?></p>
    <p>Total Amount: Ksh <?php echo htmlspecialchars($total_amount); ?></p>
    <a href="women.php" class="button">Continue Shopping</a>

    </body>
    </html>
    <?php
} else {
    // Redirect back if the form is not submitted correctly
    header("Location: payment.php");
    exit();
}
?>
