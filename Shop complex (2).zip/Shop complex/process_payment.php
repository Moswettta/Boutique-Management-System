<?php
session_start();

// Database configuration
$servername = "localhost"; // Usually localhost
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "fashion"; // Replace with your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set character set to UTF-8
$conn->set_charset("utf8");

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['payment_method'], $_POST['delivery_address'])) {
        // Get user inputs
        $username = $_SESSION['username'] ?? 'Guest'; // Get username from session or set to 'Guest'
        $delivery_address = $_POST['delivery_address'];
        $payment_method = $_POST['payment_method'];
        $total_price = $_POST['total'] ?? 0;

        // Prepare and execute the order insertion
        $stmt = $conn->prepare("INSERT INTO orders (username, delivery_address, payment_method, total_price) VALUES (?, ?, ?, ?)");
        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }

        $stmt->bind_param("sssd", $username, $delivery_address, $payment_method, $total_price);
        if (!$stmt->execute()) {
            die("Error executing statement: " . $stmt->error);
        }

        $order_id = $stmt->insert_id; // Get the last inserted order ID
        $stmt->close();

        // Prepare to insert order items
        if (isset($_SESSION["cart"])) {
            $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, item_name, price, quantity, total) VALUES (?, ?, ?, ?, ?)");
            if ($item_stmt === false) {
                die("Error preparing item statement: " . $conn->error);
            }

            foreach ($_SESSION["cart"] as $item) {
                $item_name = $item['cloth_name'];
                $price = $item['cloth_price'];
                $quantity = $item['cloth_quantity'];
                $total = $price * $quantity;

                $item_stmt->bind_param("isdds", $order_id, $item_name, $price, $quantity, $total);
                if (!$item_stmt->execute()) {
                    die("Error executing item statement: " . $item_stmt->error);
                }
            }

            $item_stmt->close();
        }

        // Clear the cart after processing payment
        unset($_SESSION["cart"]);

        // Redirect to order.php instead of receipt.php
        header("Location: order.php");
        exit();
    } else {
        echo "Payment method and delivery address are required.";
    }
}

// Close the database connection
$conn->close();
?>
