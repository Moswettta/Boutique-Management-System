<!-- product.php -->
<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fashion";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the product ID from the URL
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Query to fetch the product details by ID
    $sql = "SELECT * FROM women WHERE id = $product_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Display product details
        $row = $result->fetch_assoc();
        echo "<div class='product-detail'>";
        echo "<h1>" . $row['name'] . "</h1>";
        echo "<p><strong>Size:</strong> " . $row['size'] . "</p>";
        echo "<p><strong>Price:</strong> $" . $row['price'] . "</p>";
        echo "<div class='product-image'><img src='" . $row['image'] . "' alt='" . $row['name'] . "' /></div>";
        echo "</div>";
    } else {
        echo "Product not found.";
    }
} else {
    echo "No product selected.";
}

// Close the connection
$conn->close();
?>

<!-- Product Page Styling -->
<style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f5f5f5;
        margin: 0;
        padding: 0;
        display: flex;
    }

    .content {
        margin-left: 270px; /* To align with sidebar */
        padding: 20px;
        width: 100%;
    }

    .product-detail {
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        max-width: 600px;
        margin: auto;
        text-align: center;
    }

    .product-detail h1 {
        font-size: 2rem;
        color: #333;
    }

    .product-detail p {
        font-size: 1.2rem;
        color: #555;
        margin: 10px 0;
    }

    .product-image img {
        max-width: 100%;
        height: auto;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
</style>
