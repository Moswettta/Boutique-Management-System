
<?php include 'function.php'?>
<?php include 'config/config.php'?>
<?php
if(isset($_POST['submit']))
{
$name =$_POST['name'];
$id =$_POST['id'];
$email =$_POST['email'];
$phone =$_POST['phone'];
$pin = $_POST['password'];
$conpin =$_POST['password_confirm'];
if(empty($name) or empty ($id) or empty($email) or empty($phone) or empty($pin) or empty($conpin))
{
echo "<p>Fields Empty!</p>";
}else{
$sql="INSERT INTO user VALUES('','$name','$id','$email','$phone','$pin','$conpin',NOW())";

if($conn->query($sql)==TRUE){
  header('location:login.php');

}
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>RABUOR COMPLEX</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
    <style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;
  color: #777;
}

.bgimg-1, .bgimg-2, .bgimg-3 {
  position: relative;
  opacity: 0.65;
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

}
.bgimg-1 {
  background-image: url("images/one.jpg");
  min-height: 35%;
}

.bgimg-2 {
  background-image: url("images/two.jpg");
  min-height: 15%;
}

.bgimg-3 {
  background-image: url("images/three.jpg");
  min-height: 400px;
}

.caption {
  position: absolute;
  left: 0;
  top: 10%;
  width: 100%;
  text-align: center;
  color: #000;
}

.caption span.border {
  background-color: #111;
  color: #fff;
  padding: 18px;
  font-size: 25px;
  letter-spacing: 10px;
}

h3 {
  letter-spacing: 5px;
  text-transform: uppercase;
  font: 20px "Lato", sans-serif;
  color: #111;
}
.button {
  border-radius: 2px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 20px;
  padding: 20px;
  width: 120px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: 20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
 <header id="header">
<div class="header">
<div class="container">
  <div class="logo-nav">
    <div class="logo-nav-left">
      <h3><a href="index.php">Rabuor Shopping  <span>Complex Rabuor</span></a></h3><br>
            </div>
            <div class="log-nav-main">
            <ul class="nav navbar-nav">
    <ul class="nav navbar-right">
        <nav class="navbar navbar-inverse">
      <div class="navbar-header"></div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">

        <ul class="nav navbar-nav" id="menu">
        <a href ="index.php"><button class="button "><span>Home</span></button></a>
        

        <a href ="index.php"><button class="button "><span>Contact</span></button></a>
        <a href ="login.php"><button class="button "><span>Login</span></button></a>
        <a href ="register.php"><button class="button "><span>Register</span></button></a>

        <li><a href="logout.php"><span class=""></span></a></li>

        </ul>
        <ul class="nav navbar-right">
        </ul></div>
</a>
        </ul>
            </div>
</div>
</div>
</div>
  
</header>

</head>
<body>

<div class="bgimg-1">
  <div class="caption">
    <span class="border">Client/Register</span>
  </div>
</div>

<div style="color: #777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
  <div class="container">
            <div class="modal-dialog">

                <div class="modal-content">
                    <div class="modal-header">
                    </div>
                    <div class="modal-body">
                        
                            </form></form>
              <div id="theform">
<h3>Register Here: </h3>
<form method="post">
<tr>
              <td><label for="name">Full Name:</label></td>
              <td><input type="text" class="form-control" name="name" required></td>
            </tr>
          <tr>
              <td><label for="id">ID Number:</label></td>
              <td><input type="number" class="form-control" name="id" required></td>
            </tr>
            <tr>
              <td><label for="email">Email:</label></td>
              <td><input type="text" class="form-control" name="email" required></td>
            </tr><tr>
              <td><label for="phone">Phone:</label></td>
              <td><input type="text" class="form-control" name="phone" required></td>
            </tr>
              <td><label for="password">Password:</label></td>
              <td><input type="password" class="form-control" name="password" maxlength="6" required></td>
            </tr>
            <tr>
              <td><label for="password">Confirm Password:</label></td>
              <td><input type="password" class="form-control" name="password_confirm" maxlength="6" required></td>
            </tr>
<br/>
<input type='submit' class="btn btn-success"name='submit' value='Register'></span></input>
</form>
</div>

</div>

<div class="bgimg-2">
  <div class="caption">
    <span class="border" style="background-color:transparent;font-size:25px;color: #f7f7f7;">Get Ultimate Comfort</span>
  </div>
</div>



	
		
</body>
</html>