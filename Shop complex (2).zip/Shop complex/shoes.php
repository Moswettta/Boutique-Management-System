<?php
						session_start();


						include 'config/config.php';
if(isset($_POST['add_to_cart']))
{
	if(isset($_SESSION["cart"]))
	{
	$item_array_id = array_column($_SESSION["cart"],"id");
	if(!in_array($_GET["id"],$item_array_id))
	{
	$count= count($_SESSION["cart"]);
	$item_array = array(
	'cloth_id' 	=>	$_GET["id"],
	'cloth_name'	=>	$_POST["hidden_name"],
	'cloth_price' 	=>	$_POST["hidden_price"],
	'cloth_quantity' => 	$_POST['quantity']
	);
		$_SESSION["cart"][$count] = $item_array;

	}
	else
	{
		echo '<script>alert("Item Already Added")</script>';
				echo '<script>window.location ="prototype.php"</script>';

	}
	}
	else
	{
	$item_array = array(
	'cloth_id' 	=>	$_GET["id"],
	'cloth_name'	=>	$_POST["hidden_name"],
	'cloth_price' 	=>	$_POST["hidden_price"],
	'cloth_quantity' => 	$_POST['quantity']
	);
	$_SESSION["cart"][0] = $item_array;
	}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>RABUOR COMPLEX</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="side.css" rel="stylesheet" type="text/css"/>
	<link href="css/reservation.css" rel="stylesheet" type="text/css"/>


</head>
<body>
<div class="header">
<div class="container">
	<div class="logo-nav">
		<div class="logo-nav-left">
			<h3><a href="index.php">RABUOR COMPLEX<span>Shop anywhere</span></a></h3>
						</div>
						<div class="log-nav-main">
						<ul class="nav navbar-nav">
       <li><a href="index.php">Home</a></li>
      <li><a href="women.php">Women</a></li>
	  
      <li><a href="men.php">Men</a></li>
      <li><a href="kids.php">Children</a></li>
    </ul>
						</div>
</div>
</div>



<a href="check_out.php"><img class="responsive" src="images/viewcart.png" width="18%">
</a>
</div>
<div class="container-fluid">
<div id="content_header">

<h3>Men's Wear</h3>
</div>
<div class = "side_content">
    <ul>
			<span id="brand_header"> Categories</span><br>
        <li class="brand">
          <a href="tshirts.php">T-Shirts</a><br>
		  <a href="trousers.php">Trousers</a><br>
		  <a href="shirts.php">Shirts</a><br>
		  <a href="shoes.php">Shoes</a><br>
		  <a href="jumpers.php">Jumpers</a><br>
		  <a href="#">Caps</a><br>
		  <a href="#">Sweaters</a><br>
		  <a href="#">Jackets</a><br>
		  <a href="accessories.php">Accessories</a><br>
		  <a href="#">Socks</a><br>
		  
		  
        </li>
					<span id="brand_header">Price Range</span><br>

        <li class="brand">
          <a href="#">Price Range</a>
        </li>
					<span id="brand_header"> Brands</span><br>

        <li class="brand">
          <a href="#">Brands</a>
        </li>
					<span id="brand_header">Top Rated Products</span><br>

        <li class="brand">
          <a href="#">Top Rated Products</a>
        </li>

    </ul>
  </div>
<div class="main_content">
<div class="wears">
	
	<ul class="wears-list">

<?php
$query = "SELECT * FROM men where name = 'jordans'";
						$result = mysqli_query($conn,$query);
						if(mysqli_num_rows($result) >0)
						{
						while($row = $result->fetch_assoc())
						{
						
			?>
				<li>
									<form method="post" action="shoes.php?action=add&id=<?php echo $row['id'];?>">

					<a href="?id=<?php echo $rws['id'] ?>">
						<img class="thumb" src="admin/images/<?php echo $row['image'];?>" width="100%" height="10%">
					</a>
					<span class="price"><?php echo 'Kshs.'.$row['price'];?></span>
                    <div class="wears_details">
						<a href="join.php?id=<?php echo $row['id'] ?>"><?php $row['id'];?> </a>
						<h4><span class="property_size"><?php echo $row['name'];?></span></h4>
						<h4><span class="property_size"><?php echo $row['size'];?></span></h4>
						<input type="text" name="quantity" class="form-control" value="1"/>
						<input type="hidden" name="hidden_name" value="<?php echo $row['name'];?>"/>
						<input type="hidden" name="hidden_price" value="<?php echo $row['price'];?>"/><br>
						<input type="submit" name="add_to_cart" class="button" value="Add to cart"/>
  
					</form>
				</li>
				
			<?php
				}}
			?>
    
</ul>
</div>
</div>
</div>
