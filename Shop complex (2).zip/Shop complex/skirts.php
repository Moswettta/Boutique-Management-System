<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>RABUOR COMPLEX</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <style>
        /* General body styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* Header section */
        .header {
            background-color: #333;
            padding: 20px;
            color: white;
            text-align: center;
        }

        .header h3 {
            margin: 0;
            color: #f8b400;
            font-size: 30px;
        }

        .header h3 a {
            text-decoration: none;
            color: white;
        }

        .header h3 span {
            display: block;
            font-size: 14px;
            color: #ddd;
        }

        /* Navigation menu */
        .logo-nav-main ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            background-color: #444;
            overflow: hidden;
            text-align: center;
        }

        .logo-nav-main ul li {
            display: inline-block;
        }

        .logo-nav-main ul li a {
            padding: 14px 20px;
            display: block;
            color: white;
            text-align: center;
            text-decoration: none;
        }

        .logo-nav-main ul li a:hover {
            background-color: #f8b400;
            color: #000;
        }

        /* Cart image styling */
        .responsive {
            display: block;
            margin: 10px auto;
            width: 120px;
            height: auto;
        }

        /* Content styling */
        .container-fluid {
            display: flex;
            padding: 20px;
        }

        /* Sidebar (Categories, Brands, etc.) */
        .side_content {
            width: 25%;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px #ccc;
            margin-right: 20px;
        }

        .side_content ul {
            list-style-type: none;
            padding: 0;
        }

        .side_content ul li a {
            text-decoration: none;
            font-size: 18px;
            color: #333;
            line-height: 2;
        }

        #brand_header {
            font-weight: bold;
            font-size: 20px;
            margin-top: 10px;
            display: block;
        }

        /* Main content (Products) */
        .main_content {
            width: 75%;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px #ccc;
        }

        .wears-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            list-style-type: none;
            padding: 0;
        }

        .wears-list li {
            width: 30%;
            background-color: #f8f8f8;
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
        }

        .wears-list img {
            max-width: 100%;
            height: 150px;
            object-fit: cover;
            margin-bottom: 10px;
        }

        .price {
            font-size: 18px;
            color: #f8b400;
            font-weight: bold;
        }

        .wears_details {
            font-size: 14px;
            color: #333;
        }

        .wears_details h4 {
            margin: 5px 0;
        }

        /* Form Styling */
        .form-control {
            padding: 8px;
            width: 100%;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .button {
            padding: 10px 20px;
            background-color: #f8b400;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .button:hover {
            background-color: #333;
            color: #f8b400;
        }

        /* Footer Section */
        #content_header {
            text-align: center;
            margin-bottom: 20px;
        }

        h3 {
            color: #333;
        }
    </style>
</head>
<body>
<div class="header">
    <h3><a href="index.php">RABUOR COMPLEX<span>Shop anywhere</span></a></h3>
</div>

<div class="logo-nav-main">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="women.php">Women</a></li>
        <li><a href="men.php">Men</a></li>
        <li><a href="kids.php">Children</a></li>
    </ul>
</div>

<a href="check_out.php"><img class="responsive" src="images/viewcart.png" alt="Cart"></a>

<div class="container-fluid">
    <div class="side_content">
        <ul>
            <span id="brand_header">Categories</span><br>
            <li><a href="skirts.php">Skirts</a><br>
                <a href="handbags.php">Handbags</a><br>
                <a href="bras.php">Bras</a><br>
                <a href="women_shoes.php">Shoes</a><br>
                <a href="dress.php">Dresses</a><br>
                <a href="women_accessories.php">Accessories</a><br>
            </li>
            <span id="brand_header">Price Range</span><br>
            <li><a href="#">Price Range</a></li>
            <span id="brand_header">Brands</span><br>
            <li><a href="#">Brands</a></li>
            <span id="brand_header">Top Rated Products</span><br>
            <li><a href="#">Top Rated Products</a></li>
        </ul>
    </div>

    <div class="main_content">
        <div id="content_header">
            <h3>Women's Wear</h3>
        </div>
        <div class="wears">
            <ul class="wears-list">
                <!-- PHP product loop will go here -->
            </ul>
        </div>
    </div>
</div>
</body>
</html>
