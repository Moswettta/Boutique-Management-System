<?php
session_start();
include 'config/config.php';

// Handling add to cart
if (isset($_POST['add_to_cart'])) {
    $session_id = session_id(); // Get the current session ID
    $cloth_id = $_GET["id"];
    $cloth_name = $_POST["hidden_name"];
    $cloth_price = $_POST["hidden_price"];
    $cloth_quantity = $_POST['quantity'];
    
    // Check if the item is already in the session cart
    if (isset($_SESSION["cart"])) {
        $item_array_id = array_column($_SESSION["cart"], "cloth_id");
        if (!in_array($cloth_id, $item_array_id)) {
            $count = count($_SESSION["cart"]);
            $item_array = array(
                'cloth_id' => $cloth_id,
                'cloth_name' => $cloth_name,
                'cloth_price' => $cloth_price,
                'cloth_quantity' => $cloth_quantity
            );
            $_SESSION["cart"][$count] = $item_array;

            // Insert into the database cart table
            $insert_cart = "INSERT INTO cart (cloth_id, cloth_name, cloth_price, cloth_quantity, session_id) VALUES ('$cloth_id', '$cloth_name', '$cloth_price', '$cloth_quantity', '$session_id')";
            mysqli_query($conn, $insert_cart);
        } else {
            echo '<script>alert("Item Already Added")</script>';
            echo '<script>window.location ="home.php"</script>';
        }
    } else {
        $item_array = array(
            'cloth_id' => $cloth_id,
            'cloth_name' => $cloth_name,
            'cloth_price' => $cloth_price,
            'cloth_quantity' => $cloth_quantity
        );
        $_SESSION["cart"][0] = $item_array;

        // Insert into the database cart table
        $insert_cart = "INSERT INTO cart (cloth_id, cloth_name, cloth_price, cloth_quantity, session_id) VALUES ('$cloth_id', '$cloth_name', '$cloth_price', '$cloth_quantity', '$session_id')";
        mysqli_query($conn, $insert_cart);
    }
}

// Search logic
$search_result = [];
if (isset($_POST['search'])) {
    $search_query = $_POST['search_query'];
    
    // Store the search query into the database
    $insert_search_query = "INSERT INTO searches (query) VALUES ('$search_query')";
    mysqli_query($conn, $insert_search_query);

    // Fetch items based on search
    $search_sql = "SELECT * FROM product WHERE name LIKE '%$search_query%' OR size LIKE '%$search_query%' OR price LIKE '%$search_query%'";
    $search_result = mysqli_query($conn, $search_sql);
} else {
    // Fetch all items if no search query is provided
    $search_sql = "SELECT * FROM product ORDER BY id ASC";
    $search_result = mysqli_query($conn, $search_sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rabuor Complex</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
        }

        header {
            background-color: #333;
            padding: 10px 0;
            color: white;
            text-align: center;
        }

        header h3 {
            margin: 0;
        }

        .navbar {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 10px;
        }

        .navbar button {
            background-color: #f4511e;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
            font-size: 16px;
        }

        .navbar button:hover {
            background-color: #d1401a;
        }

        .main_content {
            width: 80%;
            margin: 20px auto;
        }

        .search-bar {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .search-bar input[type="text"] {
            padding: 10px;
            width: 50%;
            border: 1px solid #ddd;
            border-radius: 5px 0 0 5px;
            font-size: 16px;
        }

        .search-bar button {
            padding: 10px 20px;
            background-color: #f4511e;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 0 5px 5px 0;
            transition: background 0.3s;
        }

        .search-bar button:hover {
            background-color: #d1401a;
        }

        .wears-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .wears-list li {
            background-color: white;
            padding: 15px;
            border: 1px solid #ddd;
            width: 250px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .wears-list img {
            max-width: 100%;
            height: auto;
        }

        .wears-details {
            margin-top: 10px;
        }

        .price {
            font-weight: bold;
            color: #f4511e;
        }

        .form-control {
            padding: 10px;
            width: 100%;
            margin-bottom: 10px;
        }

        .button {
            display: inline-block;
            background-color: #f4511e;
            color: white;
            padding: 10px 20px;
            text-align: center;
            cursor: pointer;
            border: none;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #d1401a;
        }
    </style>
</head>
<body>

<header>
    <h3>RABUOR COMPLEX</h3>
</header>

<nav class="navbar">
    <span>Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest'; ?>!</span>
    <div>
        <a href="home.php"><button>Home</button></a>
        <a href="women.php"><button>Shop</button></a>
        <a href="check_out.php"><button>Shopping Cart</button></a>
        <a href="orders.php"><button>My Orders</button></a>
        <a href="receipt.php"><button>Receipts</button></a>
        <a href="index.php"><button>Log Out</button></a>
    </div>
</nav>

<div class="main_content">
    <h3>Women's Wear</h3>

    <!-- Search Form -->
    <form method="post" class="search-bar">
        <input type="text" name="search_query" placeholder="Search by name, size, or price..." required>
        <button type="submit" name="search">Search</button>
    </form>

    <!-- Display Search Results -->
    <ul class="wears-list">
        <?php
        if (mysqli_num_rows($search_result) > 0) {
            while ($row = mysqli_fetch_assoc($search_result)) {
        ?>
        <li>
            <form method="post" action="women.php?action=add&id=<?php echo $row['id']; ?>">
                <img src="admin/images/<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>">
                <div class="wears-details">
                    <h4><?php echo $row['name']; ?></h4>
                    <h4><?php echo $row['size']; ?></h4>
                    <span class="price">Kshs.<?php echo $row['price']; ?></span>
                    <input type="text" name="quantity" class="form-control" value="1">
                    <input type="hidden" name="hidden_name" value="<?php echo $row['name']; ?>">
                    <input type="hidden" name="hidden_price" value="<?php echo $row['price']; ?>">
                    <input type="submit" name="add_to_cart" class="button" value="Add to cart">
                </div>
            </form>
        </li>
        <?php
            }
        } else {
            echo "<p>No results found</p>";
        }
        ?>
    </ul>
</div>

</body>
</html>
